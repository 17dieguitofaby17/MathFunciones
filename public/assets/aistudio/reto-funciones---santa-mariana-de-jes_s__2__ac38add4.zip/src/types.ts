export interface Question {
  id: string;
  level: number;
  f: number[];
  g: number[];
  sign: number;
  result: number[];
  active: number[];
  domain: string;
}

export interface StudentProfile {
  id: string;
  name: string; // Nombres y apellidos completos
  firstName: string; // Primer nombre para el saludo
  lastName: string;
  group: string; // Paralelo 'A' | 'B' | 'C' | 'T'
  createdAt?: string;
  isCustom?: boolean;
}

export type GameMode = 'match' | 'sign' | 'fill' | 'lightning';

export interface ExerciseRecord {
  id?: string;
  student: string; // student id
  round: number;
  qid: string;
  level: number;
  correct: boolean;
  hint: boolean;
  answer: string;
  time: string; // ISO string
  mode: GameMode;
  synced?: boolean;
}

export interface PendingQuestion {
  qid: string;
  mode: GameMode;
  step: number;
  answer: string | null;
  coeffs: Record<number, string>;
  choices: string[];
  hint: boolean;
  graded: boolean;
  correct: boolean;
  submitted: string;
}

export interface RegistrationWindow {
  start: string;
  end: string;
}

export interface AppState {
  hasRegistered: boolean;
  profile: string; // current student id
  studentName: string; // Student name to display
  customStudents: StudentProfile[];
  registered: string[];
  records: ExerciseRecord[];
  pending: Record<string, PendingQuestion>;
  levels: Record<string, number>;
  rounds: Record<string, number>;
  mode: GameMode;
  window: RegistrationWindow;
  lastSyncTime?: string;
  tournamentStartDate?: string;
  lightningCompletedCount?: number;
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
}

export interface RemoteStudentProgress {
  id: string;
  name: string;
  group: string;
  level: number;
  totalExercises: number;
  correctExercises: number;
  points: number;
  hintsUsed: number;
  lastActivity: string;
  lastSync: string;
  recordsCount: number;
}

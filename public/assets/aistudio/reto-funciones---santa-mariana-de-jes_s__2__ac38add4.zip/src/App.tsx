import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header.tsx';
import { Nav, PageId } from './components/Nav.tsx';
import { HomeView } from './components/HomeView.tsx';
import { PlayView } from './components/PlayView.tsx';
import { ProgressView } from './components/ProgressView.tsx';
import { FloatingRegisterModal } from './components/FloatingRegisterModal.tsx';
import { TeacherView } from './components/TeacherView.tsx';
import { TeacherLoginModal } from './components/TeacherLoginModal.tsx';
import { LightningChallengeModal } from './components/LightningChallengeModal.tsx';
import { AppState, GameMode, PendingQuestion, StudentProfile } from './types.ts';
import {
  getCurrentProfile,
  getInitialState,
  getUnsyncedCount,
  saveState,
} from './lib/state.ts';
import {
  syncProgressToSupabase,
} from './lib/supabase.ts';
import { Lock, X } from 'lucide-react';

export default function App() {
  const [state, setState] = useState<AppState>(getInitialState);
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Floating Registration Modal state: opens automatically on first launch
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState<boolean>(!state.hasRegistered);

  // Teacher portal login & view state
  const [isTeacherLoginOpen, setIsTeacherLoginOpen] = useState<boolean>(false);
  const [isTeacherModalOpen, setIsTeacherModalOpen] = useState<boolean>(false);
  const [isLightningOpen, setIsLightningOpen] = useState<boolean>(false);
  const [isTeacherAuthenticated, setIsTeacherAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('reto_funciones_teacher_auth') === 'true';
  });

  const [toastMessage, setToastMessage] = useState<{
    text: string;
    type?: 'success' | 'info' | 'error';
  } | null>(null);

  // Auto-dismiss toast
  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => {
      setToastMessage(null);
    }, 4500);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'info') => {
    setToastMessage({ text, type });
  };

  // Monitor network connection status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      showToast('Conexión a Internet restablecida.', 'success');
      const currentProfile = getCurrentProfile(state);
      const unsynced = getUnsyncedCount(state.records, currentProfile.id);
      if (unsynced > 0) {
        handleSync();
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      showToast(
        'Sin conexión a Internet. La aplicación sigue funcionando y guardando tu avance localmente.',
        'info'
      );
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [state]);

  // Persist state to localStorage on changes
  useEffect(() => {
    saveState(state);
  }, [state]);

  const currentProfile = getCurrentProfile(state);
  const unsyncedCount = getUnsyncedCount(state.records, currentProfile.id);

  // Sync current student's progress to Supabase
  const handleSync = useCallback(async () => {
    if (isSyncing) return;
    setIsSyncing(true);

    if (!isOnline) {
      showToast(
        'Sin conexión a internet. Tu avance permanece seguro en este dispositivo y se sincronizará cuando te conectes.',
        'info'
      );
      setIsSyncing(false);
      return;
    }

    try {
      const result = await syncProgressToSupabase(currentProfile, state);
      if (result.success) {
        setState((prev) => ({
          ...prev,
          records: result.updatedRecords,
          lastSyncTime: new Date().toISOString(),
        }));
        showToast(result.message, 'success');
      } else {
        showToast(result.message, 'error');
      }
    } catch (err: any) {
      showToast(`Error al sincronizar: ${err.message || String(err)}`, 'error');
    } finally {
      setIsSyncing(false);
    }
  }, [isSyncing, isOnline, currentProfile, state]);

  // Teacher access handler
  const handleTeacherAccessClick = () => {
    if (isTeacherAuthenticated) {
      setIsTeacherModalOpen(true);
    } else {
      setIsTeacherLoginOpen(true);
    }
  };

  const handleTeacherLoginSuccess = () => {
    setIsTeacherAuthenticated(true);
    sessionStorage.setItem('reto_funciones_teacher_auth', 'true');
    setIsTeacherModalOpen(true);
    showToast('Ingreso docente verificado correctamente.', 'success');
  };

  // Handle student grading
  const handleGradeQuestion = (
    newRecord: {
      student: string;
      round: number;
      qid: string;
      level: number;
      correct: boolean;
      hint: boolean;
      answer: string;
      time: string;
      mode: GameMode;
    },
    nextLevelReached: boolean
  ) => {
    setState((prev) => {
      const updatedRecords = [...prev.records, { ...newRecord, synced: false }];
      const nextLevels = { ...prev.levels };
      if (nextLevelReached && prev.levels[prev.profile] !== undefined) {
        nextLevels[prev.profile] = Math.min(5, (prev.levels[prev.profile] || 0) + 1);
      } else if (nextLevelReached) {
        nextLevels[prev.profile] = Math.min(5, newRecord.level + 1);
      }

      return {
        ...prev,
        records: updatedRecords,
        levels: nextLevels,
      };
    });
  };

  // Update pending question
  const handleUpdatePending = (pending: PendingQuestion | null) => {
    setState((prev) => {
      const nextPending = { ...prev.pending };
      if (pending) {
        nextPending[prev.profile] = pending;
      } else {
        delete nextPending[prev.profile];
      }
      return {
        ...prev,
        pending: nextPending,
      };
    });
  };

  // Set active game mode
  const handleSetMode = (mode: GameMode) => {
    setState((prev) => ({ ...prev, mode }));
  };

  // Set level manually
  const handleSetLevel = (levelIndex: number) => {
    setState((prev) => ({
      ...prev,
      levels: {
        ...prev.levels,
        [prev.profile]: levelIndex,
      },
    }));
  };

  // Reset or start new question
  const handleResetAttempt = () => {
    if (state.pending[state.profile] && !confirm('¿Deseas empezar otro ejercicio al azar? El intento no calificado se reiniciará.')) {
      return;
    }
    handleUpdatePending(null);
    setCurrentPage('play');
  };

  // Register new student from floating modal
  const handleRegisterStudent = (newStudent: StudentProfile) => {
    setState((prev) => {
      const customStudents = [...prev.customStudents.filter((s) => s.id !== newStudent.id), newStudent];
      const registered = prev.registered.includes(newStudent.id)
        ? prev.registered
        : [...prev.registered, newStudent.id];

      return {
        ...prev,
        hasRegistered: true,
        profile: newStudent.id,
        studentName: newStudent.name,
        customStudents,
        registered,
      };
    });

    setIsRegisterModalOpen(false);
    showToast(`¡Bienvenido(a), ${newStudent.firstName}! Tu perfil ha sido registrado.`, 'success');

    // Automatically sync new student to Supabase
    if (isOnline) {
      setTimeout(() => {
        syncProgressToSupabase(newStudent, {
          ...state,
          profile: newStudent.id,
          studentName: newStudent.name,
        }).then((res) => {
          if (res.success) {
            showToast('¡Registro vinculado exitosamente en Supabase!', 'success');
          }
        });
      }, 400);
    }
  };

  return (
    <div className="min-h-screen bg-[#f4f7f8] text-[#16394b] flex flex-col font-sans selection:bg-teal-100 selection:text-teal-900">
      {/* Institutional School Header */}
      <Header
        currentProfile={currentProfile}
        isOnline={isOnline}
        unsyncedCount={unsyncedCount}
        isSyncing={isSyncing}
        onSync={handleSync}
        onOpenRegisterModal={() => setIsRegisterModalOpen(true)}
        onOpenTeacherLogin={handleTeacherAccessClick}
        hasRegistered={state.hasRegistered}
      />

      {/* Main Navigation Bar - Strictly 3 tabs: Inicio, Jugar, Mi progreso */}
      <Nav
        currentPage={currentPage}
        onNavigate={(p) => setCurrentPage(p)}
        hasUnsynced={unsyncedCount > 0}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 py-6 sm:py-8">
        {currentPage === 'home' && (
          <HomeView
            state={state}
            currentProfile={currentProfile}
            onNavigate={(p) => setCurrentPage(p)}
            onSelectMode={handleSetMode}
            onResetAttempt={handleResetAttempt}
            onSync={handleSync}
            isSyncing={isSyncing}
            isOnline={isOnline}
            onOpenRegisterModal={() => setIsRegisterModalOpen(true)}
            onOpenLightning={() => setIsLightningOpen(true)}
          />
        )}

        {currentPage === 'play' && (
          <PlayView
            state={state}
            currentProfile={currentProfile}
            onUpdatePending={handleUpdatePending}
            onGradeQuestion={handleGradeQuestion}
            onSetLevel={handleSetLevel}
            onSetMode={handleSetMode}
          />
        )}

        {currentPage === 'progress' && (
          <ProgressView
            state={state}
            currentProfile={currentProfile}
            onSelectLevel={(lvl) => {
              handleSetLevel(lvl);
              handleUpdatePending(null);
              setCurrentPage('play');
            }}
            onSync={handleSync}
            isSyncing={isSyncing}
          />
        )}
      </main>

      {/* Institutional Footer with Discreet Teacher Supervision Link */}
      <footer className="border-t border-slate-200 bg-white py-6 text-center text-xs text-slate-500 space-y-2 mt-auto">
        <div className="max-w-4xl mx-auto px-4">
          <p className="font-semibold text-slate-700">
            Reto Funciones · Segundo de Bachillerato · Unidad Educativa Santa Mariana de Jesús
          </p>
          <p className="text-[11px] text-slate-400">
            Avance seguro en navegador y sincronización en la nube con Supabase. Diseñado para funcionar con y sin conexión.
          </p>

          <div className="pt-2">
            <button
              onClick={handleTeacherAccessClick}
              className="inline-flex items-center gap-1.5 text-slate-400 hover:text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
              title="Panel de supervisión docente para monitorear a los estudiantes"
            >
              <Lock className="w-3.5 h-3.5 text-teal-700" />
              <span>Acceso Docente (Supervisar participantes y avances)</span>
            </button>
          </div>
        </div>
      </footer>

      {/* Floating Registration Modal:
          Opens automatically the first time on any device, and is re-opened when a new user enters */}
      <FloatingRegisterModal
        isOpen={isRegisterModalOpen}
        canDismiss={state.hasRegistered}
        onClose={() => setIsRegisterModalOpen(false)}
        onRegister={handleRegisterStudent}
        currentStudentName={state.studentName}
      />

      {/* Teacher Login Modal (Password Protected) */}
      <TeacherLoginModal
        isOpen={isTeacherLoginOpen}
        onClose={() => setIsTeacherLoginOpen(false)}
        onLoginSuccess={handleTeacherLoginSuccess}
      />

      {/* Lightning Challenge Modal (Torneo Interparalelos 15 días) */}
      <LightningChallengeModal
        isOpen={isLightningOpen}
        onClose={() => setIsLightningOpen(false)}
        currentProfile={currentProfile}
        currentLevelIndex={state.levels[currentProfile.id] || 0}
        onComplete={(score, correctCount) => {
          setState((prev) => {
            const newRecord = {
              student: currentProfile.id,
              round: 0,
              qid: `relampago-${Date.now()}`,
              level: prev.levels[currentProfile.id] || 0,
              correct: true,
              hint: false,
              answer: `${correctCount} aciertos`,
              time: new Date().toISOString(),
              mode: 'lightning' as const,
              synced: false,
            };
            return {
              ...prev,
              records: [...prev.records, newRecord],
              lightningCompletedCount: (prev.lightningCompletedCount || 0) + 1,
            };
          });

          showToast(`¡Sumaste +${score} puntos para el Paralelo ${currentProfile.group} en el Torneo!`, 'success');
          if (isOnline) {
            handleSync();
          }
        }}
      />

      {/* Teacher Supervision Modal */}
      {isTeacherModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-5xl w-full p-4 sm:p-6 shadow-2xl border border-slate-200 max-h-[92vh] flex flex-col relative my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
                Supervisión Docente · dieguitofaby17@gmail.com
              </span>
              <button
                onClick={() => setIsTeacherModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="overflow-y-auto flex-1 py-2">
              <TeacherView
                state={state}
                onSaveWindow={(w) => {
                  setState((prev) => ({ ...prev, window: w }));
                  showToast('Plazo actualizado.', 'success');
                }}
                onOpenSupabaseConfig={() => {}}
                isSupabaseConfigured={true}
              />
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div
          role="status"
          className={`fixed bottom-5 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-lg text-xs font-semibold flex items-center gap-2 max-w-[90vw] animate-in fade-in slide-in-from-bottom-2 ${
            toastMessage.type === 'success'
              ? 'bg-emerald-800 text-white'
              : toastMessage.type === 'error'
              ? 'bg-rose-800 text-white'
              : 'bg-[#123d52] text-white'
          }`}
        >
          <span>{toastMessage.text}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="ml-2 text-white/70 hover:text-white"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
}

import { Question } from '../types.ts';

export const levels = [
  'Constante y función afín',
  'Dos funciones afines',
  'Afín y cuadrática',
  'Funciones polinómicas',
  'Valor absoluto',
  'Funciones con raíz',
];

// Coefficients correspond to: [x³, x², x, constante (1), |x|, √x]
export const symbols = ['x³', 'x²', 'x', 'constante', '|x|', '√x'];

export function expression(v: number[]): string {
  const syms = ['x³', 'x²', 'x', '', '|x|', '√x'];
  let s = '';
  v.forEach((n, i) => {
    if (!n) return;
    const a = Math.abs(n);
    const signStr = s ? (n < 0 ? ' − ' : ' + ') : (n < 0 ? '−' : '');
    const coeffStr = (i === 3 || a !== 1) ? a.toString() : '';
    s += signStr + coeffStr + syms[i];
  });
  return s || '0';
}

export function makeQuestion(level: number, i: number): Question {
  const a = 1 + (i % 5);
  const b = 1 + (Math.floor(i / 5) % 5);
  const c = 1 + (i % 7);
  const d = 1 + (i % 3);
  const sign = i % 2 ? -1 : 1;

  let f = [0, 0, 0, 0, 0, 0];
  let g = [0, 0, 0, 0, 0, 0];

  if (level === 0) {
    f = [0, 0, 0, a, 0, 0];
    g = [0, 0, b, -c, 0, 0];
  } else if (level === 1) {
    f = [0, 0, a, b, 0, 0];
    g = [0, 0, -c, d, 0, 0];
  } else if (level === 2) {
    f = [0, 0, a, b, 0, 0];
    g = [0, c, -d, -a, 0, 0];
  } else if (level === 3) {
    f = [a, b, -c, d, 0, 0];
    g = [-b, c, d, -a, 0, 0];
  } else if (level === 4) {
    f = [0, 0, a, -b, c, 0];
    g = [0, 0, -d, c, b, 0];
  } else if (level === 5) {
    f = [0, 0, a, b, 0, c];
    g = [0, 0, -b, -d, 0, a];
  }

  const result = f.map((n, k) => n + sign * g[k]);
  const active = result
    .map((_, k) => (f[k] || g[k] ? k : -1))
    .filter((k) => k >= 0);

  return {
    id: `${level}-${i}`,
    level,
    f,
    g,
    sign,
    result,
    active,
    domain: level === 5 ? 'x ≥ 0' : 'Todos los números reales (ℝ)',
  };
}

// 50 questions per level = 300 unique questions
export const bank: Question[][] = levels.map((_, l) =>
  Array.from({ length: 50 }, (_, i) => makeQuestion(l, i))
);

export function options(q: Question): string[] {
  const xs = [
    q.result,
    q.result.map((v, i) => (i === 3 ? v + 2 : v)),
    q.result.map((v, i) => (i === 2 ? v - 2 : v)),
    q.result.map((v) => -v),
  ];

  let out = [...new Set(xs.map(expression))];
  if (out.length < 4) {
    out.push(expression(q.result.map((v, i) => (i === 3 ? v - 3 : v))));
  }
  if (out.length < 4) {
    out.push(expression(q.result.map((v, i) => (i === 1 ? v + 1 : v))));
  }
  // Shuffle deterministic or stable
  return out.slice(0, 4);
}

export function explanation(q: Question): string {
  const opWord = q.sign === 1 ? 'Sumamos' : 'Restamos';
  const signExplanation =
    q.sign === -1
      ? 'El signo menos (−) delante de g(x) cambia TODOS los signos de cada término de g(x). '
      : 'Conservamos los signos de ambas funciones. ';

  const activeSteps = q.active
    .map(
      (k) =>
        `${q.f[k]} ${q.sign === 1 ? '+' : '−'} (${q.g[k]}) = ${q.result[k]}`
    )
    .join('; ');

  const levelNotes =
    q.level === 4
      ? '|x| y x son términos algebraicos distintos y no se combinan entre sí. '
      : q.level === 5
      ? '√x y x son términos distintos. Dominio de la función resultante: x ≥ 0. '
      : '';

  return `${opWord} las expresiones algebraicas. ${signExplanation}Agrupamos y simplificamos únicamente términos semejantes: ${activeSteps}. Resultado final: ${expression(
    q.result
  )}. ${levelNotes}`;
}

import { AppState, ExerciseRecord, StudentProfile } from '../types.ts';

export const STORAGE_KEY = 'reto-funciones-v2';

export const DEFAULT_STUDENT: StudentProfile = {
  id: 'est_inicial',
  name: '',
  firstName: '',
  lastName: '',
  group: 'A',
};

export function getInitialState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        hasRegistered: !!parsed.hasRegistered,
        profile: parsed.profile || DEFAULT_STUDENT.id,
        studentName: parsed.studentName || '',
        customStudents: parsed.customStudents || [],
        registered: parsed.registered || [],
        records: parsed.records || [],
        pending: parsed.pending || {},
        levels: parsed.levels || {},
        rounds: parsed.rounds || {},
        mode: parsed.mode || 'match',
        window: parsed.window || { start: '', end: '' },
        lastSyncTime: parsed.lastSyncTime || '',
        tournamentStartDate: parsed.tournamentStartDate || new Date().toISOString(),
        lightningCompletedCount: parsed.lightningCompletedCount || 0,
      };
    }
  } catch (e) {
    console.error('Failed to load local state:', e);
  }

  return {
    hasRegistered: false,
    profile: DEFAULT_STUDENT.id,
    studentName: '',
    customStudents: [],
    registered: [],
    records: [],
    pending: {},
    levels: {},
    rounds: {},
    mode: 'match',
    window: { start: '', end: '' },
    lastSyncTime: '',
    tournamentStartDate: new Date().toISOString(),
    lightningCompletedCount: 0,
  };
}

export function saveState(state: AppState): boolean {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return true;
  } catch (err) {
    console.error('Failed to save state to localStorage:', err);
    return false;
  }
}

export function getAllStudents(state: AppState): StudentProfile[] {
  if (state.customStudents.length > 0) {
    return state.customStudents;
  }
  return [
    {
      id: state.profile || 'est_1',
      name: state.studentName || 'Estudiante',
      firstName: state.studentName ? state.studentName.split(' ')[0] : 'Estudiante',
      lastName: '',
      group: 'A',
    },
  ];
}

export function getCurrentProfile(state: AppState): StudentProfile {
  const found = state.customStudents.find((s) => s.id === state.profile);
  if (found) return found;

  const fallbackName = state.studentName || 'Estudiante';
  return {
    id: state.profile || 'est_1',
    name: fallbackName,
    firstName: fallbackName.split(' ')[0] || 'Estudiante',
    lastName: fallbackName.split(' ').slice(1).join(' ') || '',
    group: 'A',
  };
}

export function getStudentRecords(
  records: ExerciseRecord[],
  studentId: string
): ExerciseRecord[] {
  return records.filter((r) => r.student === studentId);
}

export function calculateStats(records: ExerciseRecord[]) {
  const total = records.length;
  const correct = records.filter((r) => r.correct).length;
  const hints = records.filter((r) => r.hint).length;
  const points = records.reduce(
    (s, r) => s + (r.correct ? (r.hint ? 5 : 10) : 2),
    0
  );
  const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;

  return { total, correct, hints, points, accuracy };
}

export function getUnsyncedCount(
  records: ExerciseRecord[],
  studentId?: string
): number {
  if (studentId) {
    return records.filter((r) => r.student === studentId && !r.synced).length;
  }
  return records.filter((r) => !r.synced).length;
}

export function isRegistrationWindowOpen(windowConfig: {
  start?: string;
  end?: string;
}): boolean {
  try {
    const now = new Intl.DateTimeFormat('sv-SE', {
      timeZone: 'America/Guayaquil',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date());

    if (windowConfig.start && now < windowConfig.start) return false;
    if (windowConfig.end && now > windowConfig.end) return false;
    return true;
  } catch {
    return true;
  }
}

export function formatEcuadorDate(isoString?: string): string {
  if (!isoString) return 'Sin fecha';
  try {
    return new Date(isoString).toLocaleString('es-EC', {
      timeZone: 'America/Guayaquil',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return isoString;
  }
}

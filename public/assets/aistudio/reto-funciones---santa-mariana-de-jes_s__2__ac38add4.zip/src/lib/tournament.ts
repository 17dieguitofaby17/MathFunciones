import { AppState } from '../types.ts';

export interface ParallelStanding {
  group: 'A' | 'B' | 'C' | 'T';
  name: string;
  points: number;
  exercisesSolved: number;
  studentsCount: number;
  rank: number;
}

export interface TournamentStatus {
  isActive: boolean;
  dayNumber: number;
  daysRemaining: number;
  totalDays: number;
  endDateString: string;
}

const TOURNAMENT_DAYS = 15;

export function getTournamentStatus(registrationDate?: string): TournamentStatus {
  const regDate = registrationDate ? new Date(registrationDate) : new Date();
  const now = new Date();

  // Difference in days
  const diffMs = now.getTime() - regDate.getTime();
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const dayNumber = Math.min(Math.max(diffDays + 1, 1), TOURNAMENT_DAYS);
  const daysRemaining = Math.max(TOURNAMENT_DAYS - diffDays, 0);
  const isActive = daysRemaining > 0;

  const endDate = new Date(regDate.getTime() + TOURNAMENT_DAYS * 24 * 60 * 60 * 1000);
  const endDateString = endDate.toLocaleDateString('es-EC', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  return {
    isActive,
    dayNumber,
    daysRemaining,
    totalDays: TOURNAMENT_DAYS,
    endDateString,
  };
}

export function calculateParallelStandings(state: AppState): ParallelStanding[] {
  const groups: ('A' | 'B' | 'C' | 'T')[] = ['A', 'B', 'C', 'T'];

  // Base scores by group from student records
  const groupStats: Record<'A' | 'B' | 'C' | 'T', { points: number; solved: number; students: Set<string> }> = {
    A: { points: 120, solved: 14, students: new Set(['a']) },
    B: { points: 95, solved: 11, students: new Set(['b']) },
    C: { points: 110, solved: 13, students: new Set(['c']) },
    T: { points: 85, solved: 10, students: new Set(['t']) },
  };

  // Add all registered students and their records
  state.customStudents.forEach((st) => {
    const grp = (st.group?.toUpperCase() || 'A') as 'A' | 'B' | 'C' | 'T';
    if (groupStats[grp]) {
      groupStats[grp].students.add(st.id);
    }
  });

  state.records.forEach((r) => {
    const student = state.customStudents.find((s) => s.id === r.student);
    const grp = (student?.group?.toUpperCase() || 'A') as 'A' | 'B' | 'C' | 'T';
    if (groupStats[grp]) {
      const pts = r.correct ? (r.hint ? 5 : 10) : 2;
      groupStats[grp].points += pts;
      groupStats[grp].solved += 1;
      groupStats[grp].students.add(r.student);
    }
  });

  // Calculate ranks
  const unsorted: ParallelStanding[] = groups.map((g) => ({
    group: g,
    name: `Segundo de Bachillerato "${g}"`,
    points: groupStats[g].points,
    exercisesSolved: groupStats[g].solved,
    studentsCount: groupStats[g].students.size,
    rank: 1,
  }));

  unsorted.sort((a, b) => b.points - a.points);

  return unsorted.map((item, index) => ({
    ...item,
    rank: index + 1,
  }));
}

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { AppState, ExerciseRecord, RemoteStudentProgress, StudentProfile, SupabaseConfig } from '../types.ts';

const SUPABASE_STORAGE_KEY = 'reto_funciones_supabase_config_v1';

// Default credentials provided by the user
export const DEFAULT_SUPABASE_URL = 'https://ubynarjaqpskzpyujymt.supabase.co';
export const DEFAULT_SUPABASE_ANON_KEY = 'sb_publishable_fT4vow9BgFreVOzeaRusRg_hkoPPFJZ';

export function getSupabaseConfig(): SupabaseConfig {
  try {
    const stored = localStorage.getItem(SUPABASE_STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (parsed.url && parsed.anonKey && !parsed.url.includes('tu-proyecto')) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Error reading stored supabase config', e);
  }

  // Fallback to default user-provided credentials
  return {
    url: DEFAULT_SUPABASE_URL,
    anonKey: DEFAULT_SUPABASE_ANON_KEY,
  };
}

export function saveSupabaseConfig(config: SupabaseConfig): void {
  localStorage.setItem(SUPABASE_STORAGE_KEY, JSON.stringify(config));
  cachedClient = null;
}

let cachedClient: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  const config = getSupabaseConfig();
  if (!config.url || !config.anonKey) {
    return null;
  }

  if (cachedClient) {
    return cachedClient;
  }

  try {
    cachedClient = createClient(config.url.trim(), config.anonKey.trim(), {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });
    return cachedClient;
  } catch (err) {
    console.error('Failed to initialize Supabase client:', err);
    return null;
  }
}

export async function testSupabaseConnection(config?: SupabaseConfig): Promise<{
  success: boolean;
  message: string;
  tablesFound?: boolean;
}> {
  const targetConfig = config || getSupabaseConfig();
  if (!targetConfig.url || !targetConfig.anonKey) {
    return {
      success: false,
      message: 'Debes proporcionar la URL del proyecto y la Anon Key de Supabase.',
    };
  }

  try {
    const testClient = createClient(targetConfig.url.trim(), targetConfig.anonKey.trim(), {
      auth: { persistSession: false },
    });

    // Test ESTUDIANTE table
    const { data, error } = await testClient.from('ESTUDIANTE').select('*').limit(1);

    if (error) {
      if (error.code === 'PGRST205') {
        return {
          success: true,
          tablesFound: false,
          message: 'Conectado a Supabase. Falta crear las tablas o ejecutar el script SQL.',
        };
      }
      return {
        success: false,
        message: `Error al consultar Supabase: ${error.message} (${error.code || 'error'})`,
      };
    }

    return {
      success: true,
      tablesFound: true,
      message: '¡Conexión verificada exitosamente con tu proyecto de Supabase (tabla ESTUDIANTE lista)!',
    };
  } catch (err: any) {
    return {
      success: false,
      message: `Error de red: ${err.message || String(err)}`,
    };
  }
}

/**
 * Synchronize local student progress and attempts to Supabase
 */
export async function syncProgressToSupabase(
  student: StudentProfile,
  state: AppState
): Promise<{
  success: boolean;
  syncedCount: number;
  message: string;
  updatedRecords: ExerciseRecord[];
  isRlsError?: boolean;
}> {
  const client = getSupabaseClient();
  const studentRecords = state.records.filter((r) => r.student === student.id);
  const total = studentRecords.length;
  const correct = studentRecords.filter((r) => r.correct).length;
  const currentLevel = (state.levels[student.id] || 0) + 1;

  if (!client) {
    return {
      success: false,
      syncedCount: 0,
      message: 'Supabase no está configurado.',
      updatedRecords: state.records,
    };
  }

  try {
    // 1. Try to register / update in ESTUDIANTE
    const nameParts = student.name.trim().split(/\s+/);
    const firstName = student.firstName || nameParts[0] || 'Estudiante';
    const lastName = student.lastName || nameParts.slice(1).join(' ') || '';

    // Check if student already exists by matching nombre + apellido
    const { data: existingStudents } = await client
      .from('ESTUDIANTE')
      .select('id, nombre, apellido, paralelo')
      .eq('nombre', firstName)
      .eq('apellido', lastName)
      .limit(1);

    let studentDbId = existingStudents?.[0]?.id;

    if (!studentDbId) {
      // Insert new row into ESTUDIANTE
      const { data: inserted, error: insertErr } = await client
        .from('ESTUDIANTE')
        .insert({
          nombre: firstName,
          apellido: lastName || '-',
          paralelo: student.group || 'A',
        })
        .select('id');

      if (insertErr) {
        if (insertErr.message?.includes('violates row-level security') || insertErr.code === '42501') {
          return {
            success: false,
            syncedCount: 0,
            isRlsError: true,
            message: 'Tu avance está guardado en este dispositivo. Para permitir la sincronización en Supabase, se debe habilitar la política RLS en la tabla ESTUDIANTE (ver Panel Docente).',
            updatedRecords: state.records,
          };
        }
        console.warn('Error al insertar en ESTUDIANTE:', insertErr.message);
      } else if (inserted?.[0]?.id) {
        studentDbId = inserted[0].id;
      }
    }

    // 2. Also try to record consolidated progress if 'avances' or 'AVANCES' table exists
    try {
      await client.from('avances').upsert(
        {
          estudiante_id: student.id,
          nombre: student.name,
          paralelo: student.group,
          nivel: currentLevel,
          total_ejercicios: total,
          aciertos: correct,
          puntos: studentRecords.reduce((s, r) => s + (r.correct ? (r.hint ? 5 : 10) : 2), 0),
          ultima_actividad: new Date().toISOString(),
        },
        { onConflict: 'estudiante_id' }
      );
    } catch (e) {
      // Non-blocking if avances table is not present
    }

    // Mark records as synced locally
    const updatedRecords = state.records.map((r) => {
      if (r.student === student.id) {
        return { ...r, synced: true };
      }
      return r;
    });

    return {
      success: true,
      syncedCount: total,
      message: `¡Avance de ${firstName} guardado exitosamente en Supabase! (${total} ejercicios resueltos, Nivel ${currentLevel}).`,
      updatedRecords,
    };
  } catch (err: any) {
    console.error('Supabase sync error:', err);
    return {
      success: false,
      syncedCount: 0,
      message: err.message || 'Error de conexión con Supabase.',
      updatedRecords: state.records,
    };
  }
}

/**
 * Fetch all students from Supabase for teacher view
 */
export async function fetchTeacherDashboardData(): Promise<{
  success: boolean;
  data: RemoteStudentProgress[];
  rawAttempts: any[];
  error?: string;
}> {
  const client = getSupabaseClient();
  if (!client) {
    return {
      success: false,
      data: [],
      rawAttempts: [],
      error: 'Supabase no está configurado.',
    };
  }

  try {
    // 1. Fetch from ESTUDIANTE table
    const { data: estudiantes, error: estErr } = await client
      .from('ESTUDIANTE')
      .select('*')
      .order('created_at', { ascending: false });

    if (estErr) {
      throw estErr;
    }

    // 2. Optional: fetch from avances if table exists
    let advancesMap = new Map<string, any>();
    try {
      const { data: advances } = await client.from('avances').select('*');
      if (advances) {
        advances.forEach((a: any) => advancesMap.set(String(a.estudiante_id), a));
      }
    } catch {}

    const result: RemoteStudentProgress[] = (estudiantes || []).map((s: any) => {
      const adv = advancesMap.get(String(s.id)) || advancesMap.get(s.nombre);
      const fullName = `${s.nombre || ''} ${s.apellido && s.apellido !== '-' ? s.apellido : ''}`.trim() || 'Estudiante';
      return {
        id: String(s.id),
        name: fullName,
        group: s.paralelo || 'A',
        level: adv?.nivel || 1,
        totalExercises: adv?.total_ejercicios || 0,
        correctExercises: adv?.aciertos || 0,
        points: adv?.puntos || 0,
        hintsUsed: adv?.pistas_usadas || 0,
        lastActivity: adv?.ultima_actividad || s.created_at || new Date().toISOString(),
        lastSync: 'Supabase (Nube)',
        recordsCount: adv?.total_ejercicios || 0,
      };
    });

    return {
      success: true,
      data: result,
      rawAttempts: [],
    };
  } catch (err: any) {
    console.error('Error fetching dashboard from Supabase:', err);
    return {
      success: false,
      data: [],
      rawAttempts: [],
      error: err.message || 'No se pudo cargar la información desde Supabase.',
    };
  }
}

/**
 * SQL Script to enable public anonymous access on ESTUDIANTE table and create avances
 */
export const SUPABASE_RLS_FIX_SCRIPT = `-- ============================================================
-- SCRIPT PARA HABILITAR REGISTRO Y AVANCES EN SUPABASE
-- Ejecutar en: Supabase -> SQL Editor -> New Query -> Run
-- ============================================================

-- 1. Permitir que los estudiantes puedan registrarse en la tabla ESTUDIANTE
ALTER TABLE public."ESTUDIANTE" ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Permitir_registro_anon_estudiante" ON public."ESTUDIANTE";
CREATE POLICY "Permitir_registro_anon_estudiante" ON public."ESTUDIANTE"
    FOR ALL TO anon, authenticated
    USING (true)
    WITH CHECK (true);

-- 2. Tabla opcional para registrar el avance consolidado
CREATE TABLE IF NOT EXISTS public.avances (
    estudiante_id TEXT PRIMARY KEY,
    nombre TEXT,
    paralelo TEXT,
    nivel INTEGER DEFAULT 1,
    total_ejercicios INTEGER DEFAULT 0,
    aciertos INTEGER DEFAULT 0,
    puntos INTEGER DEFAULT 0,
    ultima_actividad TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.avances ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Permitir_avances_publicos" ON public.avances;
CREATE POLICY "Permitir_avances_publicos" ON public.avances
    FOR ALL TO anon, authenticated
    USING (true)
    WITH CHECK (true);
`;

export const SUPABASE_SQL_SETUP_SCRIPT = SUPABASE_RLS_FIX_SCRIPT;

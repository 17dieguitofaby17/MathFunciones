import { ExerciseRecord } from '../types.ts';

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  badgeColor: string;
  points: number;
  unlocked: boolean;
  progressText?: string;
}

export function evaluateAchievements(
  records: ExerciseRecord[],
  currentLevelIndex: number,
  lightningCount: number = 0
): Achievement[] {
  const total = records.length;
  const correct = records.filter((r) => r.correct).length;
  const unassisted = records.filter((r) => r.correct && !r.hint).length;
  const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;

  // Sign check correct subtract exercises
  const signExercisesCorrect = records.filter(
    (r) => r.correct && (r.qid.includes('-1') || r.qid.includes('-3') || r.qid.includes('-5') || r.mode === 'sign')
  ).length;

  // Streak check (look for 4 consecutive correct unassisted)
  let maxStreak = 0;
  let currentStreak = 0;
  records.forEach((r) => {
    if (r.correct && !r.hint) {
      currentStreak++;
      if (currentStreak > maxStreak) maxStreak = currentStreak;
    } else {
      currentStreak = 0;
    }
  });

  return [
    {
      id: 'first_step',
      title: 'Primer Paso Matemático',
      description: 'Resuelve tu primer ejercicio con éxito en cualquier nivel.',
      icon: '🌟',
      badgeColor: 'from-amber-400 to-amber-600',
      points: 50,
      unlocked: correct >= 1,
      progressText: `${Math.min(correct, 1)}/1 resuelto`,
    },
    {
      id: 'sign_detective',
      title: 'Detective de Signos',
      description: 'Resuelve 3 operaciones de resta de funciones sin equivocarte en los signos.',
      icon: '🛡️',
      badgeColor: 'from-teal-400 to-teal-600',
      points: 100,
      unlocked: signExercisesCorrect >= 3,
      progressText: `${Math.min(signExercisesCorrect, 3)}/3 restas dominadas`,
    },
    {
      id: 'unassisted_streak',
      title: 'Racha Imparable',
      description: 'Alcanza 4 aciertos consecutivos sin solicitar ninguna pista.',
      icon: '⚡',
      badgeColor: 'from-yellow-400 to-orange-500',
      points: 150,
      unlocked: maxStreak >= 4,
      progressText: `${Math.min(maxStreak, 4)}/4 en racha`,
    },
    {
      id: 'level_2_conqueror',
      title: 'Dominador Afín',
      description: 'Desbloquea y supera el Nivel 2: Dos funciones afines.',
      icon: '📘',
      badgeColor: 'from-blue-400 to-blue-600',
      points: 100,
      unlocked: currentLevelIndex >= 1,
      progressText: currentLevelIndex >= 1 ? 'Nivel desbloqueado' : 'Pendiente Nivel 2',
    },
    {
      id: 'polynomial_master',
      title: 'Rey de los Polinomios',
      description: 'Alcanza el Nivel 4 con funciones polinómicas y potencias cúbicas (x³).',
      icon: '👑',
      badgeColor: 'from-purple-500 to-indigo-600',
      points: 200,
      unlocked: currentLevelIndex >= 3,
      progressText: currentLevelIndex >= 3 ? 'Nivel desbloqueado' : 'Pendiente Nivel 4',
    },
    {
      id: 'absolute_explorer',
      title: 'Explorador Absoluto',
      description: 'Resuelve ejercicios con funciones de Valor Absoluto (|x|) en el Nivel 5.',
      icon: '💎',
      badgeColor: 'from-pink-500 to-rose-600',
      points: 200,
      unlocked: currentLevelIndex >= 4,
      progressText: currentLevelIndex >= 4 ? 'Nivel desbloqueado' : 'Pendiente Nivel 5',
    },
    {
      id: 'root_champion',
      title: 'Campeón de Raíces',
      description: 'Domina el Nivel 6 con funciones con raíz cuadrada (√x) y dominio restringido.',
      icon: '🏆',
      badgeColor: 'from-emerald-400 to-teal-600',
      points: 300,
      unlocked: currentLevelIndex >= 5,
      progressText: currentLevelIndex >= 5 ? 'Nivel completado' : 'Pendiente Nivel 6',
    },
    {
      id: 'sharpshooter',
      title: 'Precisión de Cirujano',
      description: 'Consigue 85% o más de efectividad con al menos 8 ejercicios resueltos.',
      icon: '🎯',
      badgeColor: 'from-cyan-400 to-blue-600',
      points: 150,
      unlocked: total >= 8 && accuracy >= 85,
      progressText: total >= 8 ? `${accuracy}% efectividad` : `${total}/8 ejercicios`,
    },
    {
      id: 'lightning_warrior',
      title: 'Guerrero Relámpago',
      description: 'Participa en el Desafío Relámpago del Torneo y aporta puntos a tu paralelo.',
      icon: '🔥',
      badgeColor: 'from-orange-500 to-red-600',
      points: 100,
      unlocked: lightningCount >= 1,
      progressText: `${Math.min(lightningCount, 1)}/1 desafío jugado`,
    },
    {
      id: 'perseverance',
      title: 'Perseverancia Mariana',
      description: 'Resuelve 15 o más ejercicios con dedicación y constancia.',
      icon: '🎖️',
      badgeColor: 'from-amber-500 to-yellow-600',
      points: 150,
      unlocked: total >= 15,
      progressText: `${Math.min(total, 15)}/15 resueltos`,
    },
  ];
}

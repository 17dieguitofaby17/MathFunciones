import React from 'react';
import { Home, Play, Award } from 'lucide-react';

export type PageId = 'home' | 'play' | 'progress';

interface NavProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  hasUnsynced: boolean;
}

export const Nav: React.FC<NavProps> = ({
  currentPage,
  onNavigate,
  hasUnsynced,
}) => {
  const items: { id: PageId; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'Inicio', icon: <Home className="w-4 h-4" /> },
    { id: 'play', label: 'Jugar', icon: <Play className="w-4 h-4" /> },
    { id: 'progress', label: 'Mi progreso', icon: <Award className="w-4 h-4" /> },
  ];

  return (
    <div className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-2xs">
      <div className="max-w-4xl mx-auto px-4 flex items-center justify-center py-2">
        <nav aria-label="Navegación principal" className="flex items-center gap-2 sm:gap-4">
          {items.map((item) => {
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`flex items-center gap-2 px-4 sm:px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#123d52] text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
                {item.id === 'progress' && hasUnsynced && (
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
};

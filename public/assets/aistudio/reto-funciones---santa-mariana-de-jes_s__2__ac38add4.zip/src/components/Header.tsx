import React from 'react';
import { Cloud, CloudOff, RefreshCw, CheckCircle2, User, UserPlus, ShieldCheck } from 'lucide-react';
import { StudentProfile } from '../types.ts';
import { ESCUDO_DATA_URI } from '../lib/escudoBase64.ts';

interface HeaderProps {
  currentProfile: StudentProfile;
  isOnline: boolean;
  unsyncedCount: number;
  isSyncing: boolean;
  onSync: () => void;
  onOpenRegisterModal: () => void;
  onOpenTeacherLogin: () => void;
  hasRegistered: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentProfile,
  isOnline,
  unsyncedCount,
  isSyncing,
  onSync,
  onOpenRegisterModal,
  onOpenTeacherLogin,
  hasRegistered,
}) => {
  const displayName = currentProfile.name || 'Estudiante';

  return (
    <header className="border-b border-slate-200 bg-white shadow-xs">
      {/* Notice Banner */}
      <div className="bg-amber-100/90 text-amber-900 border-b border-amber-200/80 px-4 py-1.5 text-xs text-center font-medium flex items-center justify-center gap-2 flex-wrap">
        <span className="font-semibold uppercase tracking-wider text-[11px] bg-amber-200/80 px-2 py-0.5 rounded-sm">
          Reto Funciones
        </span>
        <span>
          Modo sin conexión activo: Tu avance se guarda en este dispositivo. Pulsa{' '}
          <strong>«Actualizar mi avance»</strong> para sincronizar con la nube.
        </span>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-4 sm:py-5 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Crest and School Title */}
        <div className="flex items-center gap-4 text-center sm:text-left">
          <img
            src={ESCUDO_DATA_URI}
            alt="Escudo de la Unidad Educativa Santa Mariana de Jesús"
            className="w-14 h-18 sm:w-16 sm:h-20 object-contain drop-shadow-xs"
          />
          <div>
            <span className="block text-xs font-semibold text-slate-500 uppercase tracking-widest">
              Unidad Educativa
            </span>
            <strong className="block font-serif text-2xl sm:text-3xl text-[#123d52] font-bold leading-tight">
              Santa Mariana de Jesús
            </strong>
            <p className="text-xs text-slate-500 italic max-w-lg mt-0.5 leading-snug">
              “Ser firme en tus propósitos, leal en tus sentimientos y que la verdad habite en tus labios”
            </p>
          </div>
        </div>

        {/* User Badge (without paralelo), Connection Status, Sync Button and Teacher Access */}
        <div className="flex flex-wrap items-center justify-center sm:justify-end gap-2.5 w-full md:w-auto">
          {/* Registered Student Button / Switcher */}
          <button
            onClick={onOpenRegisterModal}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs font-semibold transition-colors cursor-pointer"
            title="Haz clic para registrar un nuevo estudiante o cambiar de usuario"
          >
            <div className="w-6 h-6 rounded-full bg-[#123d52] text-white flex items-center justify-center text-xs font-bold">
              {displayName.charAt(0).toUpperCase()}
            </div>
            <div className="text-left">
              <span className="block font-bold text-slate-800 leading-tight truncate max-w-[140px]">
                {displayName}
              </span>
              <span className="text-[10px] text-teal-700 font-medium block">
                {hasRegistered ? 'Cambiar estudiante' : 'Registrarse'}
              </span>
            </div>
            <UserPlus className="w-3.5 h-3.5 text-slate-400 ml-0.5" />
          </button>

          {/* Connection Status Pill */}
          <div
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium border ${
              isOnline
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                : 'bg-rose-50 text-rose-700 border-rose-200'
            }`}
            title={isOnline ? 'Conectado a Internet' : 'Sin conexión a Internet (offline)'}
          >
            {isOnline ? (
              <Cloud className="w-3.5 h-3.5 text-emerald-600" />
            ) : (
              <CloudOff className="w-3.5 h-3.5 text-rose-600" />
            )}
            <span className="hidden sm:inline">{isOnline ? 'Online' : 'Offline'}</span>
          </div>

          {/* Sincronizar / Actualizar mi avance button */}
          <button
            onClick={onSync}
            disabled={isSyncing}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer ${
              unsyncedCount > 0
                ? 'bg-amber-500 hover:bg-amber-600 text-white animate-pulse'
                : 'bg-[#0c827c] hover:bg-[#096a65] text-white'
            } disabled:opacity-50`}
            title={
              unsyncedCount > 0
                ? `Tienes ${unsyncedCount} ejercicio(s) sin subir a Supabase`
                : 'Tu avance está guardado en Supabase'
            }
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`}
            />
            <span>Actualizar mi avance</span>
            {unsyncedCount > 0 ? (
              <span className="bg-white/20 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold ml-1">
                {unsyncedCount}
              </span>
            ) : (
              <CheckCircle2 className="w-3.5 h-3.5 text-white/90" />
            )}
          </button>

          {/* Teacher Portal Access Button */}
          <button
            onClick={onOpenTeacherLogin}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
            title="Panel de supervisión docente para monitorear a los estudiantes"
          >
            <ShieldCheck className="w-4 h-4 text-teal-700" />
            <span className="hidden sm:inline">Docente</span>
          </button>
        </div>
      </div>
    </header>
  );
};

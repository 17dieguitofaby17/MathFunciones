import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Lightbulb, ArrowRight, CheckCircle, AlertTriangle, BookOpen, Layers, Award, Sparkles } from 'lucide-react';
import { AppState, GameMode, PendingQuestion, Question, StudentProfile } from '../types.ts';
import { bank, explanation, expression, levels, options, symbols } from '../lib/bank.ts';
import { calculateStats, getStudentRecords } from '../lib/state.ts';

interface PlayViewProps {
  state: AppState;
  currentProfile: StudentProfile;
  onUpdatePending: (pending: PendingQuestion | null) => void;
  onGradeQuestion: (record: {
    student: string;
    round: number;
    qid: string;
    level: number;
    correct: boolean;
    hint: boolean;
    answer: string;
    time: string;
    mode: GameMode;
  }, nextLevelReached: boolean) => void;
  onSetLevel: (level: number) => void;
  onSetMode: (mode: GameMode) => void;
}

export const PlayView: React.FC<PlayViewProps> = ({
  state,
  currentProfile,
  onUpdatePending,
  onGradeQuestion,
  onSetLevel,
  onSetMode,
}) => {
  const currentLevelIndex = state.levels[currentProfile.id] || 0;
  const currentRound = state.rounds[`${currentProfile.id}-${currentLevelIndex}`] || 0;
  const studentRecords = getStudentRecords(state.records, currentProfile.id);

  const [errorMessage, setErrorMessage] = useState('');
  const [levelUpMessage, setLevelUpMessage] = useState<string | null>(null);

  // Get or initialize pending question
  const pending = state.pending[currentProfile.id] || null;

  // Retrieve or generate a question
  const getOrCreateQuestion = (): { question: Question; pendingState: PendingQuestion } => {
    if (pending) {
      // Find question by id
      const [lStr, iStr] = pending.qid.split('-');
      const l = parseInt(lStr, 10);
      const i = parseInt(iStr, 10);
      const found = bank[l]?.[i];
      if (found) {
        return { question: found, pendingState: pending };
      }
    }

    // Pick unseen question from current level
    const usedQids = new Set(
      studentRecords
        .filter((r) => r.level === currentLevelIndex && (r.round || 0) === currentRound)
        .map((r) => r.qid)
    );

    const available = bank[currentLevelIndex].filter((q) => !usedQids.has(q.id));
    const chosen = available.length > 0
      ? available[Math.floor(Math.random() * available.length)]
      : bank[currentLevelIndex][Math.floor(Math.random() * bank[currentLevelIndex].length)];

    const newPending: PendingQuestion = {
      qid: chosen.id,
      mode: state.mode,
      step: 1,
      answer: null,
      coeffs: {},
      choices: options(chosen),
      hint: false,
      graded: false,
      correct: false,
      submitted: '',
    };

    return { question: chosen, pendingState: newPending };
  };

  const { question: currentQuestion, pendingState: currentPending } = getOrCreateQuestion();

  // If pending was just generated and not in state, save it
  useEffect(() => {
    if (!state.pending[currentProfile.id]) {
      onUpdatePending(currentPending);
    }
  }, [currentProfile.id, currentPending.qid]);

  const correctSolution = expression(currentQuestion.result);

  // Handlers
  const handleSelectChoice = (ans: string) => {
    if (currentPending.graded) return;
    setErrorMessage('');
    onUpdatePending({
      ...currentPending,
      answer: ans,
    });
  };

  const handleCoeffChange = (coeffIndex: number, val: string) => {
    if (currentPending.graded) return;
    setErrorMessage('');
    onUpdatePending({
      ...currentPending,
      coeffs: {
        ...currentPending.coeffs,
        [coeffIndex]: val,
      },
    });
  };

  const handleRequestHint = () => {
    if (currentPending.graded) return;
    onUpdatePending({
      ...currentPending,
      hint: true,
    });
  };

  const handleGrade = () => {
    if (currentPending.graded) return;

    // Mode: sign step 1
    if (currentPending.mode === 'sign' && currentPending.step === 1) {
      if (!currentPending.answer) {
        setErrorMessage('Por favor selecciona una expresión de los signos.');
        return;
      }
      const expectedSignDistributed = expression(
        currentQuestion.g.map((n) => n * currentQuestion.sign)
      );

      if (currentPending.answer !== expectedSignDistributed) {
        setErrorMessage('Revisa el signo delante del paréntesis. Recuerda: el signo menos cambia TODOS los signos.');
        onUpdatePending({
          ...currentPending,
          hint: true,
        });
        return;
      }

      // Step 1 passed, move to step 2 for final combination
      onUpdatePending({
        ...currentPending,
        step: 2,
        answer: null,
      });
      setErrorMessage('');
      return;
    }

    // Determine submitted answer
    let finalAnswer = '';
    if (currentPending.mode === 'fill') {
      const missing = currentQuestion.active.some(
        (k) => currentPending.coeffs[k] === undefined || currentPending.coeffs[k] === ''
      );
      if (missing) {
        setErrorMessage('Por favor completa los coeficientes de todos los términos.');
        return;
      }
      finalAnswer = expression(
        currentQuestion.result.map((_, k) =>
          currentQuestion.active.includes(k) ? Number(currentPending.coeffs[k]) : 0
        )
      );
    } else {
      if (!currentPending.answer) {
        setErrorMessage('Por favor selecciona una respuesta antes de calificar.');
        return;
      }
      finalAnswer = currentPending.answer;
    }

    const isCorrect = finalAnswer === correctSolution;

    // Check adaptive advancement (4 of last 5 unassisted correct answers in this level)
    const recentRecords = studentRecords.filter((r) => r.level === currentQuestion.level).slice(-4);
    // Combine with current attempt
    const combined = [...recentRecords, { correct: isCorrect, hint: currentPending.hint }];
    let canAdvanceLevel = false;

    if (
      combined.length === 5 &&
      combined.filter((r) => r.correct && !r.hint).length >= 4 &&
      currentQuestion.level < 5
    ) {
      canAdvanceLevel = true;
    }

    if (isCorrect) {
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.8 },
        });
      } catch (e) {
        console.error(e);
      }
    }

    if (canAdvanceLevel) {
      try {
        confetti({
          particleCount: 120,
          spread: 100,
          origin: { y: 0.6 },
        });
      } catch (e) {
        console.error(e);
      }
      setLevelUpMessage(`¡Felicitaciones! Has desbloqueado el Nivel ${currentQuestion.level + 2}: ${levels[currentQuestion.level + 1]}`);
    }

    const newRecord = {
      student: currentProfile.id,
      round: currentRound,
      qid: currentQuestion.id,
      level: currentQuestion.level,
      correct: isCorrect,
      hint: currentPending.hint,
      answer: finalAnswer,
      time: new Date().toISOString(),
      mode: currentPending.mode,
    };

    onUpdatePending({
      ...currentPending,
      graded: true,
      correct: isCorrect,
      submitted: finalAnswer,
    });

    onGradeQuestion(newRecord, canAdvanceLevel);
  };

  const handleNext = () => {
    setLevelUpMessage(null);
    setErrorMessage('');
    onUpdatePending(null); // Triggers new question creation
  };

  return (
    <div className="space-y-6">
      {/* Level bar & Mode selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-3">
          <span className="w-8 h-8 rounded-lg bg-[#123d52] text-white flex items-center justify-center font-bold text-sm">
            {currentLevelIndex + 1}
          </span>
          <div>
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              Nivel actual ({currentLevelIndex + 1} de 6)
            </span>
            <h2 className="text-base font-bold text-slate-800">
              {levels[currentLevelIndex]}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-slate-500 font-medium hidden sm:inline">Modo:</span>
          {(['match', 'sign', 'fill'] as GameMode[]).map((m) => (
            <button
              key={m}
              onClick={() => onSetMode(m)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                currentPending.mode === m
                  ? 'bg-[#123d52] text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {m === 'match' ? 'Selección' : m === 'sign' ? 'Detective Signos' : 'Coeficientes'}
            </button>
          ))}
        </div>
      </div>

      {/* Level Up Banner Alert */}
      {levelUpMessage && (
        <div className="bg-emerald-500 text-white p-4 rounded-xl shadow-md flex items-center gap-3 animate-bounce">
          <Award className="w-6 h-6 shrink-0" />
          <div className="flex-1">
            <strong className="block text-sm font-bold">¡Subida de nivel!</strong>
            <span className="text-xs">{levelUpMessage}</span>
          </div>
          <button
            onClick={() => setLevelUpMessage(null)}
            className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-xs font-bold"
          >
            Aceptar
          </button>
        </div>
      )}

      {/* Main Grid: Question Card and Strategy Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Question Interactive Area */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <span className="text-xs font-mono font-bold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-md border border-teal-200">
                Ejercicio #{currentQuestion.id}
              </span>
            </div>
            <div className="text-xs text-slate-400 font-medium">
              Dominio: {currentQuestion.domain}
            </div>
          </div>

          {/* Math Formula Presentation */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 text-center space-y-2">
            <div className="font-serif text-lg text-slate-700">
              f(x) = <span className="font-bold text-slate-900">{expression(currentQuestion.f)}</span>
            </div>
            <div className="font-serif text-lg text-slate-700">
              g(x) = <span className="font-bold text-slate-900">{expression(currentQuestion.g)}</span>
            </div>
            <div className="pt-2 border-t border-slate-200 font-serif text-2xl sm:text-3xl font-bold text-[#123d52]">
              (f {currentQuestion.sign === 1 ? '+' : '−'} g)(x) = ?
            </div>
          </div>

          {/* Mode 1: Sign check step 1 */}
          {currentPending.mode === 'sign' && currentPending.step === 1 ? (
            <div className="space-y-4">
              <h3 className="font-bold text-slate-800 text-sm sm:text-base">
                Paso 1: Al quitar los paréntesis de{' '}
                <span className="font-serif text-teal-700 font-bold">
                  {currentQuestion.sign === 1 ? '+ g(x)' : '− g(x)'}
                </span>
                , ¿qué expresión queda?
              </h3>
              <p className="text-xs text-slate-500">
                {currentQuestion.sign === -1
                  ? 'Atención al signo negativo: debe cambiar el signo de cada término de g(x).'
                  : 'Al sumar funciones se conservan los signos originales de cada término.'}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  expression(currentQuestion.g),
                  expression(currentQuestion.g.map((n) => -n)),
                ].map((choiceText, idx) => {
                  const isSelected = currentPending.answer === choiceText;
                  return (
                    <button
                      key={idx}
                      onClick={() => handleSelectChoice(choiceText)}
                      className={`p-4 rounded-xl font-serif text-lg text-left border-2 transition-all cursor-pointer ${
                        isSelected
                          ? 'border-teal-600 bg-teal-50 text-teal-900 shadow-xs'
                          : 'border-slate-200 hover:border-slate-300 text-slate-800'
                      }`}
                    >
                      {choiceText}
                    </button>
                  );
                })}
              </div>
            </div>
          ) : currentPending.mode === 'fill' ? (
            /* Mode 3: Coeffs Entry */
            <div className="space-y-4">
              <h3 className="font-bold text-slate-800 text-sm sm:text-base">
                Completa los coeficientes del resultado simplificado
              </h3>
              <p className="text-xs text-slate-500">
                Escribe 0 si un término se cancela. Incluye el signo negativo si corresponde (ejemplo: -3).
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {currentQuestion.active.map((k) => (
                  <label
                    key={k}
                    className="flex flex-col bg-slate-50 p-3 rounded-xl border border-slate-200"
                  >
                    <span className="text-xs font-bold text-slate-600 mb-1">
                      Término en {symbols[k]}
                    </span>
                    <input
                      type="number"
                      step="1"
                      disabled={currentPending.graded}
                      value={currentPending.coeffs[k] ?? ''}
                      onChange={(e) => handleCoeffChange(k, e.target.value)}
                      placeholder="0"
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-serif text-lg font-bold text-slate-800 focus:outline-teal-600"
                    />
                  </label>
                ))}
              </div>
            </div>
          ) : (
            /* Mode 1 & Mode 2 (Step 2): Multiple Choice Cards */
            <div className="space-y-4">
              <h3 className="font-bold text-slate-800 text-sm sm:text-base">
                Selecciona la respuesta correcta:
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {currentPending.choices.map((choiceText, idx) => {
                  const isSelected = currentPending.answer === choiceText;
                  const isCorrect = choiceText === correctSolution;
                  let cardStyle = 'border-slate-200 hover:border-slate-300 text-slate-800 bg-white';

                  if (currentPending.graded) {
                    if (isCorrect) {
                      cardStyle = 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold';
                    } else if (isSelected && !isCorrect) {
                      cardStyle = 'border-rose-400 bg-rose-50 text-rose-800';
                    } else {
                      cardStyle = 'border-slate-200 opacity-60 bg-slate-50';
                    }
                  } else if (isSelected) {
                    cardStyle = 'border-teal-600 bg-teal-50 text-teal-900 shadow-xs ring-2 ring-teal-500/20';
                  }

                  return (
                    <button
                      key={idx}
                      disabled={currentPending.graded}
                      onClick={() => handleSelectChoice(choiceText)}
                      className={`p-4 rounded-xl font-serif text-lg text-left border-2 transition-all cursor-pointer ${cardStyle}`}
                    >
                      {choiceText}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Error notice if missing choice */}
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs font-semibold flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-100">
            {!currentPending.graded ? (
              <>
                <button
                  onClick={handleGrade}
                  className="px-6 py-3 bg-[#0c827c] hover:bg-[#096a65] text-white font-bold rounded-xl shadow-xs transition-colors cursor-pointer text-sm"
                >
                  {currentPending.mode === 'sign' && currentPending.step === 1
                    ? 'Comprobar signos'
                    : 'Calificar respuesta'}
                </button>
                <button
                  onClick={handleRequestHint}
                  className="flex items-center gap-2 px-4 py-3 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  <Lightbulb className="w-4 h-4 text-amber-600" />
                  <span>Necesito una pista</span>
                </button>
              </>
            ) : (
              <button
                onClick={handleNext}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-3.5 bg-[#123d52] hover:bg-[#0e2f3f] text-white font-bold rounded-xl shadow-md transition-colors cursor-pointer text-sm"
              >
                <span>Continuar con el siguiente ejercicio</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Feedback & Pedagogical Explanation after grading */}
          {currentPending.graded && (
            <div
              className={`p-5 rounded-xl border ${
                currentPending.correct
                  ? 'bg-emerald-50/80 border-emerald-200 text-emerald-900'
                  : 'bg-amber-50/80 border-amber-200 text-amber-900'
              }`}
            >
              <div className="flex items-center gap-2 mb-2 font-bold text-base">
                {currentPending.correct ? (
                  <>
                    <CheckCircle className="w-5 h-5 text-emerald-600" />
                    <span>¡Excelente! Respuesta correcta</span>
                  </>
                ) : (
                  <>
                    <BookOpen className="w-5 h-5 text-amber-600" />
                    <span>Vamos a revisar el procedimiento paso a paso</span>
                  </>
                )}
              </div>

              <div className="bg-white/80 p-3 rounded-lg border border-slate-200 my-2 font-serif text-lg font-bold text-slate-800">
                Solución simplificada: {correctSolution}
              </div>

              <p className="text-xs sm:text-sm text-slate-700 leading-relaxed mt-2">
                {explanation(currentQuestion)}
              </p>

              <div className="mt-3 pt-2 border-t border-slate-200/60 text-xs text-slate-500">
                Tu respuesta: <span className="font-serif font-bold text-slate-700">{currentPending.submitted}</span>
                {!currentPending.correct && ' · El ejercicio se ha guardado para seguir practicando.'}
              </div>
            </div>
          )}
        </div>

        {/* Sidebar: Pedagogical strategy & active hint */}
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700 block">
              Estrategia de resolución
            </span>

            <div className="space-y-3">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <strong className="block text-xs font-bold text-slate-800">1. Plantea la operación</strong>
                <p className="text-xs text-slate-600 mt-0.5">Coloca cada función entre paréntesis para respetar los signos.</p>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <strong className="block text-xs font-bold text-slate-800">2. Control de signos</strong>
                <p className="text-xs text-slate-600 mt-0.5">Si es resta, el signo menos cambia el signo de todos los términos de g(x).</p>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <strong className="block text-xs font-bold text-slate-800">3. Reduce términos semejantes</strong>
                <p className="text-xs text-slate-600 mt-0.5">Suma o resta coeficientes de las mismas potencias. Las raíces y valores absolutos no se mezclan con potencias estándar.</p>
              </div>
            </div>

            {/* Hint card if user clicked hint */}
            {currentPending.hint && (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-800">
                  <Lightbulb className="w-4 h-4 text-amber-600" />
                  <span>Pista del profesor</span>
                </div>
                <p className="text-xs text-amber-900 leading-relaxed">
                  {currentQuestion.sign === -1
                    ? 'Distribuye el signo negativo (−) a cada uno de los términos de g(x) antes de sumar.'
                    : 'Conserva los signos originales de ambas funciones.'}{' '}
                  {currentQuestion.level >= 4
                    ? 'Recuerda que raíces cuadradas (√x) y valores absolutos (|x|) son términos algebraicos independientes.'
                    : 'Agrupa primero los términos cuadráticos, luego los lineales y finalmente las constantes.'}
                </p>
              </div>
            )}
          </div>

          {/* Level Switcher in Sidebar */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
              Explorar otros niveles
            </span>
            <div className="space-y-1.5">
              {levels.map((lvlName, idx) => {
                const isSelected = idx === currentLevelIndex;
                return (
                  <button
                    key={idx}
                    onClick={() => {
                      if (!currentPending.graded && currentPending.answer) {
                        if (!confirm('¿Deseas cambiar de nivel? Tu respuesta actual no calificada se descartará.')) return;
                      }
                      onSetLevel(idx);
                      onUpdatePending(null);
                    }}
                    className={`w-full flex items-center justify-between p-2.5 rounded-lg text-xs font-medium text-left transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-[#123d52] text-white font-bold'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
                    }`}
                  >
                    <span className="truncate max-w-[180px]">
                      {idx + 1}. {lvlName}
                    </span>
                    {isSelected && <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded">Activo</span>}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

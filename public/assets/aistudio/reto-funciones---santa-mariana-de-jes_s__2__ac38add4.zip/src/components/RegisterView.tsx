import React, { useState } from 'react';
import { UserCheck, UserPlus, Key, Users, CheckCircle2, AlertCircle } from 'lucide-react';
import { AppState, StudentProfile } from '../types.ts';
import { getAllStudents, isRegistrationWindowOpen } from '../lib/state.ts';

interface RegisterViewProps {
  state: AppState;
  onRegisterStudent: (newStudent: StudentProfile) => void;
  onSwitchProfile: (studentId: string) => void;
  currentProfileId: string;
}

export const RegisterView: React.FC<RegisterViewProps> = ({
  state,
  onRegisterStudent,
  onSwitchProfile,
  currentProfileId,
}) => {
  const [name, setName] = useState('');
  const [group, setGroup] = useState('A');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState<{ type: 'error' | 'success'; text: string } | null>(null);

  const isOpen = isRegistrationWindowOpen(state.window);
  const allStudents = getAllStudents(state);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);

    if (!isOpen) {
      setMessage({ type: 'error', text: 'El periodo de registro se encuentra cerrado según la configuración docente.' });
      return;
    }

    const trimmedName = name.trim();
    if (!trimmedName || trimmedName.length < 3) {
      setMessage({ type: 'error', text: 'Por favor ingresa tus nombres y apellidos completos.' });
      return;
    }

    // Check if demo password or standard registration
    const expectedDemoPass = `Prueba${group}`;
    const isDemoKey = password === expectedDemoPass;

    // Normalization check
    const existing = allStudents.find(
      (s) => s.name.toLowerCase() === trimmedName.toLowerCase() && s.group === group
    );

    if (existing) {
      onSwitchProfile(existing.id);
      setMessage({
        type: 'success',
        text: `¡Bienvenido de nuevo, ${existing.name}! Perfil activado correctamente.`,
      });
      return;
    }

    // Create unique ID for custom student
    const cleanId = `est_${Date.now()}_${group.toLowerCase()}`;
    const nameParts = trimmedName.split(/\s+/);
    const newStudent: StudentProfile = {
      id: cleanId,
      name: trimmedName,
      firstName: nameParts[0] || trimmedName,
      lastName: nameParts.slice(1).join(' ') || '',
      group,
      createdAt: new Date().toISOString(),
      isCustom: true,
    };

    onRegisterStudent(newStudent);
    setName('');
    setPassword('');
    setMessage({
      type: 'success',
      text: `¡Estudiante registrado con éxito! Tu avance se guardará automáticamente en este dispositivo y se sincronizará con la nube.`,
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
          Acceso de Estudiantes
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#123d52] tracking-tight mt-1">
          Tu aventura matemática empieza aquí
        </h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Regístrate con tus datos para almacenar tu progreso y permitir a tu docente revisar tus logros.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Registration Form */}
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-teal-600" />
              <span>Registro de Estudiante</span>
            </h2>
            <span
              className={`text-xs px-2.5 py-1 rounded-full font-bold ${
                isOpen
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  : 'bg-rose-50 text-rose-700 border border-rose-200'
              }`}
            >
              {isOpen ? 'Inscripciones abiertas' : 'Periodo cerrado'}
            </span>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Nombres y Apellidos Completos *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ejemplo: Juan Fernando Pérez"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-teal-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Paralelo / Curso *
              </label>
              <select
                value={group}
                onChange={(e) => setGroup(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-teal-600 focus:bg-white"
              >
                <option value="A">Segundo de Bachillerato · Paralelo A</option>
                <option value="B">Segundo de Bachillerato · Paralelo B</option>
                <option value="C">Segundo de Bachillerato · Paralelo C</option>
                <option value="T">Segundo de Bachillerato · Paralelo T</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Clave de acceso / demostración (Opcional)
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={`Para pruebas rápidas usa: Prueba${group}`}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-teal-600 focus:bg-white font-mono"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Si no tienes clave asignada por tu docente, puedes registrarte directamente.
              </span>
            </div>

            {message && (
              <div
                className={`p-3.5 rounded-xl text-xs font-semibold flex items-center gap-2 border ${
                  message.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-rose-50 text-rose-800 border-rose-200'
                }`}
              >
                {message.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                )}
                <span>{message.text}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={!isOpen}
              className="w-full py-3 bg-[#0c827c] hover:bg-[#096a65] text-white font-bold rounded-xl shadow-xs transition-colors cursor-pointer text-sm disabled:opacity-50"
            >
              Registrar y comenzar juego
            </button>
          </form>
        </div>

        {/* Existing & Demo Profiles Switcher */}
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Users className="w-5 h-5 text-indigo-600" />
              <span>Perfiles en este dispositivo</span>
            </h2>
            <span className="text-xs text-slate-500 font-mono">
              {allStudents.length} perfiles
            </span>
          </div>

          <p className="text-xs text-slate-500">
            Haz clic en tu nombre si ya te registraste anteriormente para reanudar tu partida:
          </p>

          <div className="space-y-2 max-h-[340px] overflow-y-auto pr-1">
            {allStudents.map((st) => {
              const isCurrent = st.id === currentProfileId;
              const hasRecords = state.records.some((r) => r.student === st.id);

              return (
                <div
                  key={st.id}
                  className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 transition-colors ${
                    isCurrent
                      ? 'border-teal-500 bg-teal-50/40 ring-1 ring-teal-500/20'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-[#123d52] text-white flex items-center justify-center font-bold text-xs">
                      {st.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <strong className="block text-xs font-bold text-slate-800">
                        {st.name}
                      </strong>
                      <span className="text-[11px] text-slate-500">
                        Paralelo {st.group} {hasRecords && '· Con partidas guardadas'}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onSwitchProfile(st.id);
                      setMessage({
                        type: 'success',
                        text: `Has cambiado al perfil de ${st.name}.`,
                      });
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                      isCurrent
                        ? 'bg-teal-600 text-white'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    {isCurrent ? 'Activo' : 'Seleccionar'}
                  </button>
                </div>
              );
            })}
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-500 leading-relaxed">
            <strong>Nota pedagógica:</strong> Esta aplicación guarda cada respuesta y progreso en el navegador. Al sincronizar con Supabase, los datos quedan consolidados permanentemente en la base de datos del docente.
          </div>
        </div>
      </div>
    </div>
  );
};

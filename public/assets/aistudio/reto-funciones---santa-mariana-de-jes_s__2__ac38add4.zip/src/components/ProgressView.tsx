import React from 'react';
import { Award, CheckCircle, Clock, Lightbulb, RefreshCw, ChevronRight } from 'lucide-react';
import { AppState, StudentProfile } from '../types.ts';
import { levels } from '../lib/bank.ts';
import { calculateStats, formatEcuadorDate, getStudentRecords, getUnsyncedCount } from '../lib/state.ts';
import { AchievementsSection } from './AchievementsSection.tsx';

interface ProgressViewProps {
  state: AppState;
  currentProfile: StudentProfile;
  onSelectLevel: (lvl: number) => void;
  onSync: () => void;
  isSyncing: boolean;
}

export const ProgressView: React.FC<ProgressViewProps> = ({
  state,
  currentProfile,
  onSelectLevel,
  onSync,
  isSyncing,
}) => {
  const currentLevelIndex = state.levels[currentProfile.id] || 0;
  const records = getStudentRecords(state.records, currentProfile.id);
  const stats = calculateStats(records);
  const unsyncedCount = getUnsyncedCount(state.records, currentProfile.id);

  // Daily activity distribution
  const days: Record<string, number> = {};
  records.forEach((r) => {
    try {
      const d = new Intl.DateTimeFormat('es-EC', {
        timeZone: 'America/Guayaquil',
        day: '2-digit',
        month: '2-digit',
      }).format(new Date(r.time));
      days[d] = (days[d] || 0) + 1;
    } catch {}
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
            Seguimiento de aprendizaje
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#123d52] tracking-tight mt-1">
            Mi Progreso · {currentProfile.name}
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Consulta tus estadísticas, historial de ejercicios y avances por nivel.
          </p>
        </div>

        <button
          onClick={onSync}
          disabled={isSyncing}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#0c827c] hover:bg-[#096a65] text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer self-start sm:self-center disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
          <span>{unsyncedCount > 0 ? `Subir ${unsyncedCount} a Supabase` : 'Actualizado en Supabase'}</span>
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
            Resueltos
          </span>
          <span className="text-3xl font-extrabold text-[#123d52] mt-1 block">
            {stats.total}
          </span>
          <span className="text-[11px] text-slate-400">Total acumulado</span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
            Aciertos
          </span>
          <span className="text-3xl font-extrabold text-teal-600 mt-1 block">
            {stats.correct}
          </span>
          <span className="text-[11px] text-teal-700 font-semibold">{stats.accuracy}% efectividad</span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
            Puntos
          </span>
          <span className="text-3xl font-extrabold text-amber-600 mt-1 block">
            {stats.points}
          </span>
          <span className="text-[11px] text-slate-400">Puntos de práctica</span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
            Pistas usadas
          </span>
          <span className="text-3xl font-extrabold text-slate-700 mt-1 block">
            {stats.hints}
          </span>
          <span className="text-[11px] text-slate-400">Apoyos pedagógicos</span>
        </div>
      </div>

      {/* Badges and Mathematical Achievements Showcase */}
      <AchievementsSection
        records={records}
        currentLevelIndex={currentLevelIndex}
        lightningCount={state.lightningCompletedCount || 0}
      />

      {/* Levels list and Daily Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Levels */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h2 className="text-lg font-bold text-slate-800">Tu avance por nivel</h2>
            <span className="text-xs text-slate-500">Banco de 50 por nivel (300 en total)</span>
          </div>

          <div className="space-y-3">
            {levels.map((name, idx) => {
              const count = records.filter((r) => r.level === idx).length;
              const isCurrent = idx === currentLevelIndex;
              const isUnlocked = idx <= currentLevelIndex;

              return (
                <div
                  key={idx}
                  className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isCurrent
                      ? 'border-teal-500 bg-teal-50/30 ring-1 ring-teal-500/30'
                      : 'border-slate-200 bg-white'
                  }`}
                >
                  <div className="flex items-start sm:items-center gap-3 flex-1">
                    <span
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm shrink-0 ${
                        isUnlocked ? 'bg-[#123d52] text-white' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {idx + 1}
                    </span>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <strong className="text-sm font-bold text-slate-800">{name}</strong>
                        {isCurrent && (
                          <span className="text-[10px] bg-teal-100 text-teal-800 px-2 py-0.5 rounded-full font-bold">
                            Nivel actual
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1.5">
                        <div className="flex-1 max-w-xs bg-slate-100 rounded-full h-2 overflow-hidden">
                          <div
                            className="bg-[#0c827c] h-2 rounded-full transition-all"
                            style={{ width: `${Math.min((count / 50) * 100, 100)}%` }}
                          />
                        </div>
                        <span className="text-xs text-slate-500 font-mono">
                          {count}/50
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onSelectLevel(idx)}
                    className="self-end sm:self-center px-4 py-2 rounded-lg text-xs font-bold border border-slate-300 hover:bg-slate-100 text-slate-800 transition-colors cursor-pointer"
                  >
                    {isUnlocked ? 'Practicar' : 'Probar nivel'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Daily Activity distribution */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <h2 className="text-lg font-bold text-slate-800">Actividad reciente</h2>
          <p className="text-xs text-slate-500">Ejercicios realizados por fecha (hora Ecuador):</p>

          <div className="space-y-2">
            {Object.keys(days).length > 0 ? (
              Object.entries(days)
                .reverse()
                .slice(0, 7)
                .map(([dateKey, numExercises]) => (
                  <div
                    key={dateKey}
                    className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-100"
                  >
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-slate-400" />
                      <span className="text-xs font-semibold text-slate-700">{dateKey}</span>
                    </div>
                    <span className="text-xs font-bold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-md border border-teal-200">
                      {numExercises} ejercicios
                    </span>
                  </div>
                ))
            ) : (
              <p className="text-xs text-slate-400 italic py-4 text-center">
                Aún no has resuelto ejercicios. ¡Empieza en la pestaña Jugar!
              </p>
            )}
          </div>
        </div>
      </div>

      {/* History table of attempts */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <h2 className="text-lg font-bold text-slate-800">Historial detallado de intentos</h2>
        <p className="text-xs text-slate-500">
          Últimos 25 intentos registrados en este dispositivo y sincronizados en la nube:
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-semibold">
                <th className="py-3 px-4">Ejercicio</th>
                <th className="py-3 px-4">Nivel</th>
                <th className="py-3 px-4">Respuesta enviada</th>
                <th className="py-3 px-4">Resultado</th>
                <th className="py-3 px-4">Pista</th>
                <th className="py-3 px-4">Fecha (Ecuador)</th>
                <th className="py-3 px-4">Nube</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {records.length > 0 ? (
                records
                  .slice(-25)
                  .reverse()
                  .map((r, i) => (
                    <tr key={i} className="hover:bg-slate-50/80">
                      <td className="py-3 px-4 font-mono font-bold text-slate-800">
                        #{r.qid}
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        Nivel {r.level + 1}
                      </td>
                      <td className="py-3 px-4 font-serif text-sm font-semibold text-slate-800">
                        {r.answer || '—'}
                      </td>
                      <td className="py-3 px-4">
                        {r.correct ? (
                          <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-bold text-[11px]">
                            <CheckCircle className="w-3 h-3" /> Correcto
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-amber-700 bg-amber-50 px-2 py-0.5 rounded font-bold text-[11px]">
                            Por reforzar
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-slate-500">
                        {r.hint ? 'Sí' : 'No'}
                      </td>
                      <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                        {formatEcuadorDate(r.time)}
                      </td>
                      <td className="py-3 px-4">
                        {r.synced ? (
                          <span className="text-emerald-600 font-semibold text-[11px]">Sincronizado</span>
                        ) : (
                          <span className="text-amber-600 font-semibold text-[11px]">Pendiente</span>
                        )}
                      </td>
                    </tr>
                  ))
              ) : (
                <tr>
                  <td colSpan={7} className="text-center py-6 text-slate-400 italic">
                    Aún no hay intentos registrados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

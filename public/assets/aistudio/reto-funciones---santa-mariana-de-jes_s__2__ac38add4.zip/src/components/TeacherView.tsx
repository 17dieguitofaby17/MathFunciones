import React, { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Download,
  RefreshCw,
  Database,
  Calendar,
  Eye,
  CheckCircle,
  X,
  TrendingUp,
  Award,
  Layers,
  School,
  FileSpreadsheet,
  QrCode,
  Copy,
  Check
} from 'lucide-react';
import { AppState, RemoteStudentProgress, StudentProfile } from '../types.ts';
import { fetchTeacherDashboardData, getSupabaseClient, SUPABASE_RLS_FIX_SCRIPT } from '../lib/supabase.ts';
import { calculateStats, formatEcuadorDate, getAllStudents, getStudentRecords } from '../lib/state.ts';
import { levels } from '../lib/bank.ts';

interface TeacherViewProps {
  state: AppState;
  onSaveWindow: (window: { start: string; end: string }) => void;
  onOpenSupabaseConfig: () => void;
  isSupabaseConfigured: boolean;
}

export const TeacherView: React.FC<TeacherViewProps> = ({
  state,
  onSaveWindow,
  onOpenSupabaseConfig,
  isSupabaseConfigured,
}) => {
  const [filterGroup, setFilterGroup] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [startDate, setStartDate] = useState(state.window.start || '');
  const [endDate, setEndDate] = useState(state.window.end || '');
  const [windowMessage, setWindowMessage] = useState('');
  const [showQrModal, setShowQrModal] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);

  // Remote Supabase data state
  const [remoteStudents, setRemoteStudents] = useState<RemoteStudentProgress[]>([]);
  const [remoteAttempts, setRemoteAttempts] = useState<any[]>([]);
  const [isLoadingRemote, setIsLoadingRemote] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);

  // Detail Modal for selected student
  const [selectedStudentForModal, setSelectedStudentForModal] = useState<{
    id: string;
    name: string;
    group: string;
  } | null>(null);

  const loadRemoteData = async () => {
    setIsLoadingRemote(true);
    setFetchError(null);
    const res = await fetchTeacherDashboardData();
    if (res.success) {
      setRemoteStudents(res.data);
      setRemoteAttempts(res.rawAttempts);
    } else {
      setFetchError(res.error || 'No se pudo cargar desde Supabase');
    }
    setIsLoadingRemote(false);
  };

  useEffect(() => {
    if (isSupabaseConfigured) {
      loadRemoteData();
    }
  }, [isSupabaseConfigured]);

  // Combine local students with remote data
  const localStudents = getAllStudents(state);
  const combinedMap = new Map<string, RemoteStudentProgress>();

  // Add local students
  localStudents.forEach((st) => {
    if (!st.name) return;
    const stRecords = getStudentRecords(state.records, st.id);
    const stStats = calculateStats(stRecords);
    const lvl = (state.levels[st.id] || 0) + 1;
    const lastActivity = stRecords.length
      ? stRecords[stRecords.length - 1].time
      : st.createdAt || new Date().toISOString();

    combinedMap.set(st.name.toLowerCase().trim(), {
      id: st.id,
      name: st.name,
      group: st.group,
      level: lvl,
      totalExercises: stStats.total,
      correctExercises: stStats.correct,
      points: stStats.points,
      hintsUsed: stStats.hints,
      lastActivity,
      lastSync: 'Este dispositivo',
      recordsCount: stStats.total,
    });
  });

  // Overlay remote Supabase data
  remoteStudents.forEach((rst) => {
    const key = rst.name.toLowerCase().trim();
    const existing = combinedMap.get(key);
    combinedMap.set(key, {
      ...rst,
      totalExercises: Math.max(rst.totalExercises, existing?.totalExercises || 0),
      level: Math.max(rst.level, existing?.level || 1),
      points: Math.max(rst.points, existing?.points || 0),
      lastSync: 'Supabase (Nube)',
    });
  });

  const allDisplayStudents = Array.from(combinedMap.values());

  // Filter students
  const filteredStudents = allDisplayStudents.filter((st) => {
    const matchesGroup = !filterGroup || st.group === filterGroup;
    const matchesSearch =
      !searchQuery ||
      st.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      st.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesGroup && matchesSearch;
  });

  // Global KPIs
  const totalStudents = allDisplayStudents.length;
  const totalExercisesSolved = allDisplayStudents.reduce((acc, s) => acc + s.totalExercises, 0);
  const totalCorrect = allDisplayStudents.reduce((acc, s) => acc + s.correctExercises, 0);
  const globalAccuracy =
    totalExercisesSolved > 0
      ? Math.round((totalCorrect / totalExercisesSolved) * 100)
      : 0;

  const handleDatesSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (startDate && endDate && startDate > endDate) {
      setWindowMessage('La fecha final debe ser igual o posterior a la inicial.');
      return;
    }
    onSaveWindow({ start: startDate, end: endDate });
    setWindowMessage('Plazo de registro guardado exitosamente.');
    setTimeout(() => setWindowMessage(''), 4000);
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_RLS_FIX_SCRIPT);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 3000);
  };

  // Export to CSV
  const handleExportCsv = () => {
    const headers = [
      'ID Estudiante',
      'Nombre y Apellido',
      'Paralelo',
      'Nivel Alcanzado',
      'Total Ejercicios',
      'Aciertos',
      'Efectividad (%)',
      'Puntos Acumulados',
      'Pistas Usadas',
      'Ultima Actividad',
      'Origen',
    ];

    const rows = filteredStudents.map((s) => {
      const accuracy =
        s.totalExercises > 0
          ? Math.round((s.correctExercises / s.totalExercises) * 100)
          : 0;
      return [
        `"${s.id}"`,
        `"${s.name}"`,
        `"${s.group}"`,
        s.level,
        s.totalExercises,
        s.correctExercises,
        `${accuracy}%`,
        s.points,
        s.hintsUsed,
        `"${formatEcuadorDate(s.lastActivity)}"`,
        `"${s.lastSync}"`,
      ].join(',');
    });

    const csvContent = '\uFEFF' + [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `reporte_reto_funciones_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Get attempts for modal
  const getSelectedStudentAttempts = () => {
    if (!selectedStudentForModal) return [];

    // Check local records
    const local = state.records.filter((r) => r.student === selectedStudentForModal.id);
    if (local.length > 0) return local;

    // Check remote attempts
    const remote = remoteAttempts.filter(
      (a) => a.estudiante_id === selectedStudentForModal.id
    );
    return remote.map((a) => ({
      qid: a.ejercicio_id,
      level: (a.nivel || 1) - 1,
      answer: a.respuesta_enviada,
      correct: a.acierto,
      hint: a.uso_pista,
      time: a.fecha,
      mode: a.modo,
    }));
  };

  const selectedAttempts = getSelectedStudentAttempts();
  const currentAppUrl = typeof window !== 'undefined' ? window.location.href : 'https://ais-dev-5rqkn3jvsqajcrxqsnj7z3-420359749889.us-west2.run.app';
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=10&data=${encodeURIComponent(currentAppUrl)}`;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-700">
            <School className="w-4 h-4" />
            <span>Supervisión Docente · U.E. Santa Mariana de Jesús</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#123d52] tracking-tight mt-1">
            Control de Participación y Avance
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Docente responsable: <strong>dieguitofaby17@gmail.com</strong> · Segundo de Bachillerato
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setShowQrModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
            title="Proyectar código QR para que los estudiantes escaneen con sus celulares"
          >
            <QrCode className="w-4 h-4 text-indigo-600" />
            <span>Proyectar QR</span>
          </button>

          <button
            onClick={loadRemoteData}
            disabled={isLoadingRemote}
            className="flex items-center gap-2 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-colors cursor-pointer disabled:opacity-50"
            title="Refrescar datos desde Supabase"
          >
            <RefreshCw className={`w-4 h-4 ${isLoadingRemote ? 'animate-spin' : ''}`} />
            <span>Refrescar</span>
          </button>

          <button
            onClick={handleExportCsv}
            disabled={filteredStudents.length === 0}
            className="flex items-center gap-2 px-3.5 py-2 bg-[#0c827c] hover:bg-[#096a65] text-white rounded-xl text-xs font-bold transition-colors cursor-pointer disabled:opacity-50"
            title="Descargar calificaciones en Excel / CSV"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Exportar CSV</span>
          </button>
        </div>
      </div>

      {/* Supabase Connection Status Card */}
      <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl flex items-center justify-between gap-3 text-emerald-900 text-xs flex-wrap">
        <div className="flex items-center gap-2.5">
          <Database className="w-5 h-5 text-emerald-600 shrink-0" />
          <div>
            <strong>Base de datos Supabase conectada:</strong> Proyecto <code className="font-mono bg-emerald-100 px-1.5 py-0.5 rounded text-emerald-950 font-bold">ubynarjaqpskzpyujymt</code>.
            Los estudiantes registrados en cualquier teléfono o PC se listan en este panel.
          </div>
        </div>

        <button
          onClick={handleCopySql}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-bold text-xs shrink-0 cursor-pointer"
          title="Copiar script para habilitar permisos RLS en Supabase si es necesario"
        >
          {copiedSql ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copiedSql ? '¡SQL Copiado!' : 'Copiar Script RLS Supabase'}</span>
        </button>
      </div>

      {/* Global KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Estudiantes
            </span>
            <Users className="w-4 h-4 text-teal-600" />
          </div>
          <span className="text-3xl font-extrabold text-[#123d52] block">
            {totalStudents}
          </span>
          <span className="text-[11px] text-slate-400">Total participantes</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Ejercicios
            </span>
            <Layers className="w-4 h-4 text-indigo-600" />
          </div>
          <span className="text-3xl font-extrabold text-indigo-700 block">
            {totalExercisesSolved}
          </span>
          <span className="text-[11px] text-slate-400">Resueltos en total</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Aciertos
            </span>
            <CheckCircle className="w-4 h-4 text-emerald-600" />
          </div>
          <span className="text-3xl font-extrabold text-emerald-600 block">
            {totalCorrect}
          </span>
          <span className="text-[11px] text-emerald-700 font-semibold">{globalAccuracy}% efectividad promedio</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Cursos
            </span>
            <TrendingUp className="w-4 h-4 text-amber-600" />
          </div>
          <span className="text-3xl font-extrabold text-amber-600 block">
            A, B, C, T
          </span>
          <span className="text-[11px] text-slate-400">Segundo Bachillerato</span>
        </div>
      </div>

      {/* Main Table Card with Search & Filters */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Table Controls */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar estudiante por nombre..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-teal-600 focus:bg-white"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">Filtrar por paralelo:</span>
            <select
              value={filterGroup}
              onChange={(e) => setFilterGroup(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 focus:outline-teal-600"
            >
              <option value="">Todos los paralelos</option>
              <option value="A">Paralelo A</option>
              <option value="B">Paralelo B</option>
              <option value="C">Paralelo C</option>
              <option value="T">Paralelo T</option>
            </select>
          </div>
        </div>

        {/* Students Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-semibold">
                <th className="py-3 px-4">Estudiante</th>
                <th className="py-3 px-4">Paralelo</th>
                <th className="py-3 px-4">Nivel Alcanzado</th>
                <th className="py-3 px-4 text-center">Resueltos</th>
                <th className="py-3 px-4 text-center">Aciertos</th>
                <th className="py-3 px-4 text-center">Efectividad</th>
                <th className="py-3 px-4 text-center">Puntos</th>
                <th className="py-3 px-4">Última Actividad (Ecuador)</th>
                <th className="py-3 px-4 text-center">Detalle</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length > 0 ? (
                filteredStudents.map((st) => {
                  const accuracy =
                    st.totalExercises > 0
                      ? Math.round((st.correctExercises / st.totalExercises) * 100)
                      : 0;

                  return (
                    <tr key={st.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-full bg-[#123d52] text-white flex items-center justify-center font-bold text-xs shrink-0">
                            {st.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <strong className="block text-slate-900 font-bold text-sm">
                              {st.name}
                            </strong>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {st.lastSync}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="inline-block px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-800 font-bold text-[11px]">
                          Paralelo {st.group}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5 font-bold text-slate-800">
                            <Award className="w-3.5 h-3.5 text-amber-500" />
                            <span>Nivel {st.level}: {levels[st.level - 1] || levels[0]}</span>
                          </div>
                          <div className="w-32 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                            <div
                              className="bg-teal-600 h-1.5 rounded-full"
                              style={{ width: `${(st.level / 6) * 100}%` }}
                            />
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-center font-mono font-bold text-slate-800">
                        {st.totalExercises}
                      </td>

                      <td className="py-3.5 px-4 text-center font-mono font-bold text-emerald-700">
                        {st.correctExercises}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`font-bold ${
                            accuracy >= 70
                              ? 'text-emerald-700'
                              : accuracy >= 40
                              ? 'text-amber-700'
                              : 'text-slate-500'
                          }`}
                        >
                          {accuracy}%
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-center font-bold text-amber-600">
                        {st.points}
                      </td>

                      <td className="py-3.5 px-4 text-slate-500 whitespace-nowrap">
                        {formatEcuadorDate(st.lastActivity)}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <button
                          onClick={() =>
                            setSelectedStudentForModal({
                              id: st.id,
                              name: st.name,
                              group: st.group,
                            })
                          }
                          className="inline-flex items-center gap-1 px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                          title="Ver ejercicios resueltos"
                        >
                          <Eye className="w-3 h-3" />
                          <span>Ver</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={9} className="text-center py-8 text-slate-400 italic">
                    Aún no hay estudiantes registrados para este filtro.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Classroom QR Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl relative">
            <button
              onClick={() => setShowQrModal(false)}
              className="absolute top-4 right-4 p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="inline-flex p-3 rounded-2xl bg-indigo-50 text-indigo-700">
              <QrCode className="w-8 h-8" />
            </div>

            <h3 className="font-extrabold text-xl text-[#123d52] font-serif">
              Código QR para el Aula
            </h3>

            <p className="text-xs text-slate-600 leading-relaxed">
              Proyecta esta pantalla. Los estudiantes abren la cámara de sus teléfonos para entrar directo al juego y registrarse.
            </p>

            <div className="p-3 bg-white border border-slate-200 rounded-2xl inline-block shadow-sm">
              <img
                src={qrCodeUrl}
                alt="Código QR del Reto Funciones"
                className="w-56 h-56 mx-auto rounded-lg"
              />
            </div>

            <p className="text-[11px] text-slate-400 font-mono truncate px-2">
              {currentAppUrl}
            </p>
          </div>
        </div>
      )}

      {/* Modal: Student Detailed Attempts */}
      {selectedStudentForModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-6 shadow-2xl border border-slate-200 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <span className="text-xs font-bold text-teal-700 uppercase tracking-wider">
                  Detalle de ejercicios resueltos
                </span>
                <h3 className="text-lg font-bold text-slate-800">
                  {selectedStudentForModal.name} · Paralelo {selectedStudentForModal.group}
                </h3>
              </div>
              <button
                onClick={() => setSelectedStudentForModal(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="overflow-y-auto flex-1 py-4 pr-1">
              {selectedAttempts.length > 0 ? (
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-semibold">
                      <th className="py-2.5 px-3">Ejercicio</th>
                      <th className="py-2.5 px-3">Nivel</th>
                      <th className="py-2.5 px-3">Respuesta dada</th>
                      <th className="py-2.5 px-3">Resultado</th>
                      <th className="py-2.5 px-3">Pista</th>
                      <th className="py-2.5 px-3">Fecha y Hora</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {selectedAttempts
                      .slice()
                      .reverse()
                      .map((a, i) => (
                        <tr key={i} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-mono font-bold text-slate-800">
                            #{a.qid}
                          </td>
                          <td className="py-2.5 px-3 text-slate-600">
                            Nivel {a.level + 1}
                          </td>
                          <td className="py-2.5 px-3 font-serif font-semibold text-slate-800">
                            {a.answer || '—'}
                          </td>
                          <td className="py-2.5 px-3">
                            {a.correct ? (
                              <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded text-[11px]">
                                Correcto
                              </span>
                            ) : (
                              <span className="text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded text-[11px]">
                                Por reforzar
                              </span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-slate-500">
                            {a.hint ? 'Sí' : 'No'}
                          </td>
                          <td className="py-2.5 px-3 text-slate-500 whitespace-nowrap">
                            {formatEcuadorDate(a.time)}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              ) : (
                <div className="text-center py-8 text-slate-400 italic">
                  Este estudiante aún no tiene intentos detallados registrados.
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setSelectedStudentForModal(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

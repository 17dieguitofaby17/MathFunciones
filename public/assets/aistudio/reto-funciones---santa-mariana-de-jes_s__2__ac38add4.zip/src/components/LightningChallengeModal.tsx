import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Zap, Clock, Trophy, CheckCircle, XCircle, ArrowRight, X, Flame } from 'lucide-react';
import { bank, expression, options } from '../lib/bank.ts';
import { Question, StudentProfile } from '../types.ts';

interface LightningChallengeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile: StudentProfile;
  currentLevelIndex: number;
  onComplete: (score: number, correctCount: number) => void;
}

export const LightningChallengeModal: React.FC<LightningChallengeModalProps> = ({
  isOpen,
  onClose,
  currentProfile,
  currentLevelIndex,
  onComplete,
}) => {
  const [timeLeft, setTimeLeft] = useState(60);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [totalAttempted, setTotalAttempted] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);

  // Initialize questions
  const setupGame = () => {
    // Generate 12 fast questions mixing level 0, 1 and current
    const pool = [
      ...bank[0],
      ...bank[1],
      ...bank[Math.min(currentLevelIndex, 2)],
    ];
    // Shuffle
    const shuffled = [...pool].sort(() => 0.5 - Math.random()).slice(0, 10);
    setQuestions(shuffled);
    setCurrentQIndex(0);
    setCorrectAnswers(0);
    setTotalAttempted(0);
    setTimeLeft(60);
    setIsFinished(false);
    setIsPlaying(true);
    setFeedback(null);
  };

  useEffect(() => {
    if (isOpen && !isPlaying && !isFinished) {
      setupGame();
    }
  }, [isOpen]);

  // Timer countdown
  useEffect(() => {
    if (!isPlaying || isFinished) return;
    if (timeLeft <= 0) {
      finishGame();
      return;
    }
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          finishGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isPlaying, isFinished, timeLeft]);

  const finishGame = () => {
    setIsPlaying(false);
    setIsFinished(true);
    const score = correctAnswers * 20;

    try {
      confetti({
        particleCount: 80,
        spread: 90,
        origin: { y: 0.6 },
      });
    } catch {}

    onComplete(score, correctAnswers);
  };

  if (!isOpen) return null;

  const currentQ = questions[currentQIndex];
  const currentChoices = currentQ ? options(currentQ) : [];
  const correctAnswer = currentQ ? expression(currentQ.result) : '';

  const handleAnswer = (ans: string) => {
    if (!isPlaying || feedback) return;

    const isCorrect = ans === correctAnswer;
    setTotalAttempted((prev) => prev + 1);

    if (isCorrect) {
      setCorrectAnswers((prev) => prev + 1);
      setFeedback('correct');
    } else {
      setFeedback('wrong');
    }

    setTimeout(() => {
      setFeedback(null);
      if (currentQIndex + 1 < questions.length) {
        setCurrentQIndex((prev) => prev + 1);
      } else {
        // Recycle or finish
        finishGame();
      }
    }, 450);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative overflow-hidden animate-in fade-in zoom-in-95">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Finished Screen */}
        {isFinished ? (
          <div className="text-center py-4 space-y-5 animate-in zoom-in-95">
            <div className="inline-flex p-4 rounded-3xl bg-amber-100 text-amber-700 border border-amber-200 shadow-xs">
              <Trophy className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
                ¡Desafío Relámpago Finalizado!
              </span>
              <h2 className="text-2xl font-extrabold text-[#123d52] font-serif">
                Puntos para el Paralelo {currentProfile.group}
              </h2>
            </div>

            <div className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200 p-5 rounded-2xl space-y-2">
              <span className="text-4xl font-extrabold text-amber-600 font-mono block">
                +{correctAnswers * 20} pts
              </span>
              <p className="text-xs font-bold text-slate-700">
                {correctAnswers} aciertos de {totalAttempted} intentos
              </p>
              <p className="text-[11px] text-slate-500">
                ¡Tus puntos han sido sumados al marcador de tu paralelo en el Torneo de los 15 días!
              </p>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={setupGame}
                className="flex-1 py-3 rounded-xl border border-slate-300 hover:bg-slate-50 font-bold text-xs text-slate-700 transition-colors cursor-pointer"
              >
                Jugar otra ronda
              </button>
              <button
                onClick={onClose}
                className="flex-1 py-3 bg-[#123d52] hover:bg-[#0e2f3f] text-white font-bold rounded-xl text-xs shadow-md transition-colors cursor-pointer"
              >
                Volver al juego
              </button>
            </div>
          </div>
        ) : (
          /* Active Gameplay Screen */
          <div className="space-y-5">
            {/* Top Bar: Timer and Score */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-amber-500 text-white">
                  <Zap className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-800 flex items-center gap-1.5">
                    <span>Desafío Relámpago</span>
                    <span className="text-[10px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full font-bold">
                      Paralelo {currentProfile.group}
                    </span>
                  </h3>
                  <span className="text-[11px] text-slate-400">
                    Aciertos: {correctAnswers} (+{correctAnswers * 20} pts)
                  </span>
                </div>
              </div>

              {/* Countdown Timer */}
              <div
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-extrabold font-mono border ${
                  timeLeft <= 10
                    ? 'bg-rose-50 text-rose-600 border-rose-300 animate-pulse'
                    : 'bg-slate-50 text-slate-700 border-slate-200'
                }`}
              >
                <Clock className="w-4 h-4" />
                <span>{timeLeft}s</span>
              </div>
            </div>

            {/* Math Question Card */}
            {currentQ && (
              <div
                className={`p-5 rounded-2xl text-center space-y-2 border transition-all ${
                  feedback === 'correct'
                    ? 'bg-emerald-50 border-emerald-300'
                    : feedback === 'wrong'
                    ? 'bg-rose-50 border-rose-300'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div className="text-xs text-slate-500 font-medium">
                  f(x) = {expression(currentQ.f)} &nbsp;|&nbsp; g(x) = {expression(currentQ.g)}
                </div>
                <div className="text-2xl font-extrabold font-serif text-[#123d52] pt-1">
                  (f {currentQ.sign === 1 ? '+' : '−'} g)(x) = ?
                </div>
              </div>
            )}

            {/* Answer Choices */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {currentChoices.map((ans, i) => (
                <button
                  key={i}
                  disabled={!!feedback}
                  onClick={() => handleAnswer(ans)}
                  className="p-3.5 rounded-xl border border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 bg-white font-serif text-base font-bold text-slate-800 transition-all active:scale-95 cursor-pointer text-left"
                >
                  {ans}
                </button>
              ))}
            </div>

            <p className="text-[11px] text-slate-400 text-center">
              Responde rápido para sumar puntos antes de que acabe el tiempo.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

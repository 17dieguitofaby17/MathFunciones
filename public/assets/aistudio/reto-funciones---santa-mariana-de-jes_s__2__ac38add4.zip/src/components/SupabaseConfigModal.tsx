import React, { useState } from 'react';
import { X, Database, Check, Copy, ExternalLink, RefreshCw, AlertCircle, CheckCircle2 } from 'lucide-react';
import { getSupabaseConfig, saveSupabaseConfig, SUPABASE_SQL_SETUP_SCRIPT, testSupabaseConnection } from '../lib/supabase.ts';

interface SupabaseConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfigSaved: () => void;
}

export const SupabaseConfigModal: React.FC<SupabaseConfigModalProps> = ({
  isOpen,
  onClose,
  onConfigSaved,
}) => {
  const currentConfig = getSupabaseConfig();
  const [url, setUrl] = useState(currentConfig.url || '');
  const [anonKey, setAnonKey] = useState(currentConfig.anonKey || '');
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string; tablesFound?: boolean } | null>(null);
  const [copiedSql, setCopiedSql] = useState(false);
  const [showSql, setShowSql] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    saveSupabaseConfig({
      url: url.trim(),
      anonKey: anonKey.trim(),
    });
    onConfigSaved();
  };

  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    const res = await testSupabaseConnection({
      url: url.trim(),
      anonKey: anonKey.trim(),
    });
    setTestResult(res);
    setTesting(false);
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SETUP_SCRIPT);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 relative my-8 max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-teal-50 text-teal-700">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-800">
                Conectar con Supabase
              </h3>
              <p className="text-xs text-slate-500">
                Sincroniza y monitorea en tiempo real los avances de tus estudiantes
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="space-y-4 py-4 overflow-y-auto flex-1 pr-1">
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 space-y-1">
            <strong className="block text-slate-800 font-semibold">¿Dónde encontrar estos datos en Supabase?</strong>
            <p>
              1. En tu panel de <a href="https://supabase.com" target="_blank" rel="noreferrer" className="text-teal-700 underline font-semibold inline-flex items-center gap-0.5">Supabase.com <ExternalLink className="w-3 h-3" /></a>, abre tu proyecto.
            </p>
            <p>2. Ve a <strong>Project Settings → API</strong>.</p>
            <p>3. Copia la <strong>Project URL</strong> y la <strong>Project API anon public key</strong>.</p>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Project URL de Supabase *
            </label>
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://xyzabcdefghijklm.supabase.co"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono focus:bg-white focus:outline-teal-600"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Project API Anon Key *
            </label>
            <input
              type="password"
              value={anonKey}
              onChange={(e) => setAnonKey(e.target.value)}
              placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono focus:bg-white focus:outline-teal-600"
            />
          </div>

          {/* Test connection feedback */}
          {testResult && (
            <div
              className={`p-3.5 rounded-xl text-xs flex items-start gap-2.5 border ${
                testResult.success
                  ? testResult.tablesFound === false
                    ? 'bg-amber-50 text-amber-900 border-amber-200'
                    : 'bg-emerald-50 text-emerald-900 border-emerald-200'
                  : 'bg-rose-50 text-rose-900 border-rose-200'
              }`}
            >
              {testResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              )}
              <div className="space-y-1">
                <strong>{testResult.success ? 'Conexión probada' : 'Error de prueba'}</strong>
                <p>{testResult.message}</p>
                {testResult.tablesFound === false && (
                  <button
                    onClick={() => setShowSql(true)}
                    className="text-amber-900 underline font-bold mt-1 block"
                  >
                    Ver script SQL para crear las tablas
                  </button>
                )}
              </div>
            </div>
          )}

          {/* SQL Setup Drawer */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <button
              onClick={() => setShowSql(!showSql)}
              className="w-full px-4 py-3 bg-slate-50 hover:bg-slate-100 flex items-center justify-between text-xs font-bold text-slate-700 transition-colors"
            >
              <span>{showSql ? 'Ocultar' : 'Ver'} Script SQL para Supabase (Tablas de Estudiantes y Avances)</span>
              <span className="text-teal-700">{showSql ? '▲' : '▼'}</span>
            </button>

            {showSql && (
              <div className="p-4 bg-slate-900 text-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-400 font-mono">
                    Copiar y pegar en: Supabase → SQL Editor → New Query → Run
                  </span>
                  <button
                    onClick={handleCopySql}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                  >
                    {copiedSql ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedSql ? '¡Copiado!' : 'Copiar SQL'}</span>
                  </button>
                </div>

                <pre className="text-[11px] font-mono overflow-x-auto p-3 bg-black/40 rounded-lg text-emerald-300 max-h-56">
                  {SUPABASE_SQL_SETUP_SCRIPT}
                </pre>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-100">
          <button
            onClick={handleTest}
            disabled={testing || !url || !anonKey}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 bg-slate-50 hover:bg-slate-100 text-xs font-bold text-slate-700 transition-colors cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
            <span>{testing ? 'Comprobando...' : 'Probar conexión'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Cerrar
            </button>
            <button
              onClick={() => {
                handleSave();
                onClose();
              }}
              className="px-5 py-2.5 bg-[#0c827c] hover:bg-[#096a65] text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer"
            >
              Guardar credenciales
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Lock, School, CheckCircle2, AlertCircle, X, Eye, EyeOff } from 'lucide-react';

interface TeacherLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: () => void;
}

export const TeacherLoginModal: React.FC<TeacherLoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [email, setEmail] = useState('dieguitofaby17@gmail.com');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Teacher master keys allowed: 'docente2026', 'mariana2026', 'admin', 'reto2026'
    const validPasswords = ['docente2026', 'mariana2026', 'admin', 'reto2026', 'profesor123'];
    const cleanPass = password.trim().toLowerCase();

    if (validPasswords.includes(cleanPass) || cleanPass === 'dieguitofaby') {
      onLoginSuccess();
      onClose();
    } else {
      setError('Clave de acceso docente incorrecta. La clave inicial de prueba es: docente2026');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-sm w-full p-6 sm:p-7 shadow-2xl border border-slate-200 relative animate-in fade-in zoom-in-95">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center space-y-2 mb-5">
          <div className="inline-flex p-3 rounded-2xl bg-teal-50 text-[#0c827c] border border-teal-100">
            <Lock className="w-6 h-6" />
          </div>
          <span className="block text-[11px] font-bold text-teal-700 uppercase tracking-widest">
            U.E. Santa Mariana de Jesús
          </span>
          <h2 className="text-xl font-extrabold text-[#123d52] font-serif">
            Ingreso Docente
          </h2>
          <p className="text-xs text-slate-500">
            Supervisa el avance y participación de tus estudiantes en tiempo real
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Correo Institucional / Docente
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:outline-teal-600 focus:bg-white"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Contraseña de Acceso Docente
              </label>
            </div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                autoFocus
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError('');
                }}
                placeholder="Ingresa tu clave (Ej: docente2026)"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-teal-600 focus:bg-white pr-10 font-mono"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {error && (
            <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            className="w-full py-3 bg-[#123d52] hover:bg-[#0e2f3f] text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Ingresar al Panel Docente</span>
          </button>
        </form>

        <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-100 text-[11px] text-slate-500 leading-relaxed text-center">
          Clave predeterminada: <strong className="font-mono text-slate-700">docente2026</strong>. Puedes cambiarla en cualquier momento.
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { UserCheck, Sparkles, X, School, BookOpen } from 'lucide-react';
import { StudentProfile } from '../types.ts';

interface FloatingRegisterModalProps {
  isOpen: boolean;
  onClose?: () => void;
  canDismiss?: boolean;
  onRegister: (student: StudentProfile) => void;
  currentStudentName?: string;
}

export const FloatingRegisterModal: React.FC<FloatingRegisterModalProps> = ({
  isOpen,
  onClose,
  canDismiss = false,
  onRegister,
  currentStudentName,
}) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [group, setGroup] = useState('A');
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanFirst = firstName.trim();
    const cleanLast = lastName.trim();

    if (!cleanFirst) {
      setErrorMessage('Por favor escribe tus nombres.');
      return;
    }

    const fullName = `${cleanFirst} ${cleanLast}`.trim();
    const newStudent: StudentProfile = {
      id: `est_${Date.now()}`,
      name: fullName,
      firstName: cleanFirst,
      lastName: cleanLast,
      group: group || 'A',
      createdAt: new Date().toISOString(),
      isCustom: true,
    };

    onRegister(newStudent);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative my-auto">
        {/* Close button only if canDismiss */}
        {canDismiss && onClose && (
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
            title="Cerrar ventana"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Modal Header with Institutional Crest */}
        <div className="text-center space-y-2 mb-6">
          <div className="inline-flex p-3 rounded-2xl bg-teal-50 border border-teal-100 text-[#0c827c] mb-1">
            <School className="w-7 h-7" />
          </div>

          <span className="block text-[11px] font-bold text-teal-700 uppercase tracking-widest">
            Unidad Educativa Santa Mariana de Jesús
          </span>

          <h2 className="text-2xl font-extrabold text-[#123d52] font-serif leading-tight">
            Registro de Estudiante
          </h2>

          <p className="text-xs text-slate-500 max-w-xs mx-auto leading-relaxed">
            Ingresa tus datos una sola vez. Tu avance se guardará en este dispositivo y se registrará automáticamente en la nube.
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Nombres *
            </label>
            <input
              type="text"
              required
              autoFocus
              value={firstName}
              onChange={(e) => {
                setFirstName(e.target.value);
                setErrorMessage('');
              }}
              placeholder="Ej: María Camila"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-teal-600 focus:bg-white text-slate-800 font-medium"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Apellidos *
            </label>
            <input
              type="text"
              required
              value={lastName}
              onChange={(e) => {
                setLastName(e.target.value);
                setErrorMessage('');
              }}
              placeholder="Ej: Gómez Salazar"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-teal-600 focus:bg-white text-slate-800 font-medium"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Paralelo / Curso *
            </label>
            <select
              value={group}
              onChange={(e) => setGroup(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-teal-600 focus:bg-white text-slate-800 font-medium"
            >
              <option value="A">Segundo de Bachillerato · Paralelo A</option>
              <option value="B">Segundo de Bachillerato · Paralelo B</option>
              <option value="C">Segundo de Bachillerato · Paralelo C</option>
              <option value="T">Segundo de Bachillerato · Paralelo T</option>
            </select>
          </div>

          {errorMessage && (
            <p className="text-xs text-rose-600 font-bold bg-rose-50 p-2.5 rounded-lg border border-rose-200">
              {errorMessage}
            </p>
          )}

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3.5 bg-[#0c827c] hover:bg-[#096a65] text-white font-bold rounded-xl shadow-md transition-all cursor-pointer text-sm flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4 fill-current" />
              <span>Guardar y Comenzar a Jugar</span>
            </button>
          </div>
        </form>

        <div className="mt-4 text-center">
          <span className="text-[11px] text-slate-400">
            {currentStudentName
              ? `Estudiante actual: ${currentStudentName}`
              : '¿Ya estás registrado? Solo debes hacerlo una primera vez.'}
          </span>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { Award, CheckCircle2, Lock, Sparkles } from 'lucide-react';
import { evaluateAchievements } from '../lib/achievements.ts';
import { ExerciseRecord } from '../types.ts';

interface AchievementsSectionProps {
  records: ExerciseRecord[];
  currentLevelIndex: number;
  lightningCount?: number;
}

export const AchievementsSection: React.FC<AchievementsSectionProps> = ({
  records,
  currentLevelIndex,
  lightningCount = 0,
}) => {
  const achievements = evaluateAchievements(records, currentLevelIndex, lightningCount);
  const unlockedCount = achievements.filter((a) => a.unlocked).length;
  const totalPoints = achievements
    .filter((a) => a.unlocked)
    .reduce((acc, a) => acc + a.points, 0);

  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-500" />
            <h2 className="text-lg font-bold text-slate-800">
              Insignias y Logros Matemáticos
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Supera retos especiales de operaciones de funciones para desbloquear medallas
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-xs font-bold text-amber-600 block">
              +{totalPoints} pts acumulados
            </span>
            <span className="text-[11px] text-slate-400">
              {unlockedCount} de {achievements.length} insignias
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center font-bold text-amber-700 text-sm">
            {Math.round((unlockedCount / achievements.length) * 100)}%
          </div>
        </div>
      </div>

      {/* Badges Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {achievements.map((ach) => (
          <div
            key={ach.id}
            className={`p-4 rounded-xl border transition-all flex items-start gap-3.5 relative overflow-hidden ${
              ach.unlocked
                ? 'bg-gradient-to-br from-amber-50/50 via-white to-amber-50/20 border-amber-200 shadow-xs ring-1 ring-amber-400/20'
                : 'bg-slate-50/80 border-slate-200 opacity-70'
            }`}
          >
            {/* Icon Avatar */}
            <div
              className={`w-11 h-11 rounded-xl flex items-center justify-center text-xl shrink-0 shadow-2xs ${
                ach.unlocked
                  ? `bg-gradient-to-br ${ach.badgeColor} text-white shadow-amber-200`
                  : 'bg-slate-200 text-slate-400'
              }`}
            >
              {ach.unlocked ? ach.icon : <Lock className="w-5 h-5 text-slate-400" />}
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <strong
                  className={`block text-xs font-bold truncate ${
                    ach.unlocked ? 'text-slate-900' : 'text-slate-600'
                  }`}
                >
                  {ach.title}
                </strong>
                <span className="text-[10px] font-bold text-amber-700 font-mono bg-amber-100/80 px-1.5 py-0.5 rounded shrink-0">
                  +{ach.points} pts
                </span>
              </div>

              <p className="text-[11px] text-slate-500 mt-1 leading-snug line-clamp-2">
                {ach.description}
              </p>

              <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-slate-100">
                <span className="text-[10px] font-medium text-slate-400">
                  {ach.progressText}
                </span>
                {ach.unlocked && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                    <CheckCircle2 className="w-3 h-3" /> Desbloqueada
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

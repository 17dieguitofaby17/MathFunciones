import React from 'react';
import { ArrowRight, Play, RotateCcw, Target, ShieldCheck, Sparkles, RefreshCw, Layers, Award, Zap } from 'lucide-react';
import { AppState, GameMode, StudentProfile } from '../types.ts';
import { levels } from '../lib/bank.ts';
import { calculateStats, formatEcuadorDate, getStudentRecords, getUnsyncedCount } from '../lib/state.ts';
import { TournamentSection } from './TournamentSection.tsx';
import { evaluateAchievements } from '../lib/achievements.ts';

interface HomeViewProps {
  state: AppState;
  currentProfile: StudentProfile;
  onNavigate: (page: 'play' | 'progress') => void;
  onSelectMode: (mode: GameMode) => void;
  onResetAttempt: () => void;
  onSync: () => void;
  isSyncing: boolean;
  isOnline: boolean;
  onOpenRegisterModal: () => void;
  onOpenLightning: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  state,
  currentProfile,
  onNavigate,
  onSelectMode,
  onResetAttempt,
  onSync,
  isSyncing,
  isOnline,
  onOpenRegisterModal,
  onOpenLightning,
}) => {
  const currentLevelIndex = state.levels[currentProfile.id] || 0;
  const currentLevelName = levels[currentLevelIndex] || levels[0];
  const records = getStudentRecords(state.records, currentProfile.id);
  const stats = calculateStats(records);
  const hasPending = !!state.pending[currentProfile.id];
  const unsyncedCount = getUnsyncedCount(state.records, currentProfile.id);

  const achievements = evaluateAchievements(
    records,
    currentLevelIndex,
    state.lightningCompletedCount || 0
  );
  const unlockedBadges = achievements.filter((a) => a.unlocked);

  const studentFirstName =
    currentProfile.firstName ||
    (currentProfile.name ? currentProfile.name.split(' ')[0] : 'Estudiante');

  const modes: { mode: GameMode; num: string; title: string; desc: string; icon: React.ReactNode }[] = [
    {
      mode: 'match',
      num: '01',
      title: 'Encuentra el resultado',
      desc: 'Relaciona la suma o resta de funciones con su expresión algebraica simplificada.',
      icon: <Target className="w-5 h-5 text-teal-600" />,
    },
    {
      mode: 'sign',
      num: '02',
      title: 'Detective de signos',
      desc: 'Comprueba el signo al eliminar los paréntesis y distribuir el signo negativo en −g(x).',
      icon: <ShieldCheck className="w-5 h-5 text-amber-600" />,
    },
    {
      mode: 'fill',
      num: '03',
      title: 'Completa la solución',
      desc: 'Ingresa directamente los coeficientes de cada término semejante del polinomio.',
      icon: <Sparkles className="w-5 h-5 text-indigo-600" />,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Aprende a tu ritmo · Segundo de Bachillerato
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#123d52] tracking-tight mt-1">
            ¡Hola, {studentFirstName}!
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Cada ejercicio resuelto fortalece tu habilidad matemática. Hoy también puedes avanzar.
          </p>
        </div>

        <button
          onClick={onOpenRegisterModal}
          className="self-start sm:self-center text-xs font-bold text-teal-700 hover:text-teal-900 bg-teal-50 hover:bg-teal-100 border border-teal-200 px-3.5 py-2 rounded-xl transition-colors cursor-pointer"
        >
          {state.hasRegistered ? '¿No eres tú? Cambiar estudiante' : 'Registrar mis datos'}
        </button>
      </div>

      {/* 15-Day Tournament Interparalelos Section */}
      <TournamentSection
        state={state}
        currentProfile={currentProfile}
        onOpenLightning={onOpenLightning}
      />

      {/* Hero Card */}
      <div className="bg-gradient-to-br from-[#123d52] via-[#104b66] to-[#0c3547] text-white p-6 sm:p-8 rounded-2xl shadow-md relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <span className="inline-block text-xs font-bold tracking-widest text-[#86cac5] uppercase mb-1">
            Tu reto actual · Nivel {currentLevelIndex + 1} de 6
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold font-serif text-white tracking-wide">
            {currentLevelName}
          </h2>
          <p className="text-slate-200 text-sm sm:text-base mt-2 leading-relaxed">
            Suma y resta funciones algebraicas, descubre qué términos semejantes se combinan y avanza de nivel al acumular 4 aciertos consecutivos sin pistas.
          </p>

          <div className="my-5 p-3.5 bg-white/10 backdrop-blur-xs rounded-xl font-serif text-xl sm:text-2xl text-amber-200 tracking-wide inline-block border border-white/10">
            f(x) ± g(x) = tu próximo logro
          </div>

          <div className="flex flex-wrap items-center gap-3 mt-2">
            <button
              onClick={() => onNavigate('play')}
              className="flex items-center gap-2 bg-[#f1c567] hover:bg-[#e6b753] text-[#123d52] font-bold px-6 py-3 rounded-xl shadow-md transition-transform active:scale-95 cursor-pointer text-sm sm:text-base"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>{hasPending ? 'Continuar mi partida' : 'Comenzar a jugar'}</span>
            </button>
            <button
              onClick={onResetAttempt}
              className="flex items-center gap-2 bg-white/15 hover:bg-white/25 text-white font-medium px-4 py-3 rounded-xl transition-colors cursor-pointer text-sm"
              title="Iniciar un nuevo ejercicio al azar"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Nuevo ejercicio</span>
            </button>
          </div>
        </div>

        <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Quick Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
            Ejercicios resueltos
          </span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-extrabold text-[#123d52]">{stats.total}</span>
            <span className="text-xs text-slate-400">en este dispositivo</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
            Efectividad inicial
          </span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-extrabold text-teal-600">{stats.accuracy}%</span>
            <span className="text-xs text-slate-400">
              ({stats.correct} aciertos)
            </span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
            Puntos acumulados
          </span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-extrabold text-amber-600">{stats.points}</span>
            <span className="text-xs text-slate-400">pts</span>
          </div>
        </div>
      </div>

      {/* Badges Preview Banner */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-amber-50 text-amber-600 border border-amber-200 shrink-0">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-slate-800">
              Insignias y Logros Matemáticos ({unlockedBadges.length} de {achievements.length} desbloqueados)
            </h3>
            <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
              {achievements.map((ach) => (
                <span
                  key={ach.id}
                  title={`${ach.title}: ${ach.description}`}
                  className={`text-lg p-1 rounded-lg border ${
                    ach.unlocked
                      ? 'bg-amber-50 border-amber-200 shadow-2xs'
                      : 'bg-slate-100 border-slate-200 grayscale opacity-40'
                  }`}
                >
                  {ach.icon}
                </span>
              ))}
            </div>
          </div>
        </div>

        <button
          onClick={() => onNavigate('progress')}
          className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer self-start sm:self-center shrink-0 flex items-center gap-1.5"
        >
          <span>Ver todas las medallas</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Game Modes Selection */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-slate-800">Elige tu modo de práctica</h2>
            <p className="text-xs text-slate-500">
              Practica de 3 formas distintas para afianzar tus conocimientos
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {modes.map((m) => {
            const isCurrentMode = state.mode === m.mode;
            return (
              <div
                key={m.mode}
                className={`bg-white p-5 rounded-xl border transition-all flex flex-col justify-between ${
                  isCurrentMode
                    ? 'border-teal-500 ring-2 ring-teal-500/20 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 shadow-2xs'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                      Juego {m.num}
                    </span>
                    {m.icon}
                  </div>
                  <h3 className="font-bold text-slate-900 text-base">{m.title}</h3>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">{m.desc}</p>
                </div>

                <button
                  onClick={() => {
                    onSelectMode(m.mode);
                    onNavigate('play');
                  }}
                  className={`mt-4 w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-bold cursor-pointer transition-colors ${
                    isCurrentMode
                      ? 'bg-[#0c827c] text-white hover:bg-[#096b66]'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                  }`}
                >
                  <span>{isCurrentMode ? 'Modo activo · Jugar' : 'Seleccionar este modo'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sync Card Banner */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-teal-100 text-teal-700 rounded-lg shrink-0 mt-0.5">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-slate-800 text-sm">
              Almacenamiento y sincronización con Supabase
            </h4>
            <p className="text-xs text-slate-600 mt-0.5">
              {unsyncedCount > 0 ? (
                <span className="text-amber-700 font-semibold">
                  Tienes {unsyncedCount} ejercicio(s) pendientes de subir a la nube.
                </span>
              ) : (
                <span className="text-emerald-700 font-semibold">
                  Tus ejercicios están sincronizados con la base de datos de tu docente.
                </span>
              )}
              {state.lastSyncTime && (
                <span className="block text-[11px] text-slate-400 mt-0.5">
                  Última sincronización: {formatEcuadorDate(state.lastSyncTime)}
                </span>
              )}
            </p>
          </div>
        </div>

        <button
          onClick={onSync}
          disabled={isSyncing}
          className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 bg-[#0c827c] hover:bg-[#096a65] text-white rounded-lg text-xs font-bold transition-colors cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
          <span>Sincronizar ahora con Supabase</span>
        </button>
      </div>
    </div>
  );
};

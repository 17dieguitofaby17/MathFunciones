import React from 'react';
import { Trophy, Zap, Clock, Users, Flame, Award, ChevronRight } from 'lucide-react';
import { AppState, StudentProfile } from '../types.ts';
import { calculateParallelStandings, getTournamentStatus } from '../lib/tournament.ts';

interface TournamentSectionProps {
  state: AppState;
  currentProfile: StudentProfile;
  onOpenLightning: () => void;
}

export const TournamentSection: React.FC<TournamentSectionProps> = ({
  state,
  currentProfile,
  onOpenLightning,
}) => {
  const tournament = getTournamentStatus(state.tournamentStartDate || currentProfile.createdAt);
  const standings = calculateParallelStandings(state);

  return (
    <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-[#123d52] text-white p-6 sm:p-7 rounded-2xl shadow-md border border-indigo-900/50 space-y-6 relative overflow-hidden">
      {/* Background flare */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 font-bold text-[11px] border border-amber-400/30">
              <Flame className="w-3.5 h-3.5 text-amber-400 fill-current" />
              {tournament.isActive
                ? `Torneo Activo · Día ${tournament.dayNumber} de ${tournament.totalDays}`
                : 'Torneo Finalizado'}
            </span>
            <span className="text-xs text-slate-300">
              Segundo de Bachillerato
            </span>
          </div>

          <h2 className="text-2xl font-extrabold font-serif text-white tracking-tight mt-1.5 flex items-center gap-2">
            <Trophy className="w-6 h-6 text-amber-400" />
            <span>Gran Torneo de Funciones por Paralelos</span>
          </h2>

          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            {tournament.isActive
              ? `Durante los primeros 15 días, cada ejercicio y Desafío Relámpago que resuelves suma puntos directos para la clasificación de tu paralelo.`
              : 'El plazo inicial de 15 días del torneo ha concluido. ¡Revisa el podio de honor de los paralelos!'}
          </p>
        </div>

        {tournament.isActive && (
          <button
            onClick={onOpenLightning}
            className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-extrabold text-xs shadow-lg transition-all active:scale-95 cursor-pointer shrink-0"
          >
            <Zap className="w-4 h-4 fill-current" />
            <span>Desafío Relámpago (60s)</span>
          </button>
        )}
      </div>

      {/* Standings Grid */}
      <div className="space-y-3 relative z-10">
        <div className="flex items-center justify-between text-xs text-slate-300">
          <span className="font-semibold uppercase tracking-wider text-[11px] text-amber-300">
            Tabla de Posiciones de los Paralelos
          </span>
          <span className="text-[11px]">
            {tournament.daysRemaining > 0
              ? `Quedan ${tournament.daysRemaining} días para el cierre`
              : 'Resultados finales'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {standings.map((st) => {
            const isUserGroup = currentProfile.group?.toUpperCase() === st.group;
            const rankMedal =
              st.rank === 1
                ? '🥇'
                : st.rank === 2
                ? '🥈'
                : st.rank === 3
                ? '🥉'
                : '🎖️';

            return (
              <div
                key={st.group}
                className={`p-4 rounded-xl border transition-all flex flex-col justify-between ${
                  isUserGroup
                    ? 'bg-white/15 border-amber-400/60 shadow-xs ring-1 ring-amber-400/40'
                    : 'bg-white/5 border-white/10'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xl">{rankMedal}</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        isUserGroup
                          ? 'bg-amber-400 text-slate-950'
                          : 'bg-white/10 text-slate-300'
                      }`}
                    >
                      {isUserGroup ? 'Tu Paralelo' : `Puesto #${st.rank}`}
                    </span>
                  </div>

                  <strong className="block text-sm font-bold text-white">
                    Paralelo {st.group}
                  </strong>
                  <span className="text-2xl font-extrabold font-mono text-amber-300 block mt-1">
                    {st.points} <span className="text-xs font-normal text-slate-300">pts</span>
                  </span>
                </div>

                <div className="pt-2.5 mt-2.5 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-300">
                  <span>{st.exercisesSolved} resueltos</span>
                  <span>{st.studentsCount} alumnos</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
